import React from 'react';
import { motion } from 'motion/react';
import { ArrowDown, MessageCircle, MapPin, Sparkles, Instagram, Phone } from 'lucide-react';
import { STORE_INFO } from '../data/storeData';
import { BrandLogo } from './BrandLogo';

export const Hero: React.FC = () => {
  return (
    <section className="relative overflow-hidden pt-8 pb-16 lg:pt-14 lg:pb-24 border-b border-white/10">
      {/* Background radial glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-white/[0.03] blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Swipe Down: Drop announcement tag */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex justify-center sm:justify-start mb-6"
        >
          <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-zinc-900/90 border border-white/15 text-xs text-zinc-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-[11px] uppercase tracking-wider text-zinc-400">BHARUCH ARCHIVE DROP 01</span>
            <span className="text-zinc-600">·</span>
            <span className="text-zinc-300 font-medium">Curated 4-Piece Portfolio</span>
          </div>
        </motion.div>

        {/* 2-Column Split: Left text (Left-to-Right animation) & Right media (Right-to-Left animation) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Left-to-Right Animation */}
          <motion.div
            initial={{ opacity: 0, x: -60 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 flex flex-col text-center sm:text-left"
          >
            {/* Website Name prominently highlighted in bold letters */}
            <div className="mb-4">
              <h1 className="text-4xl sm:text-6xl xl:text-7xl font-black tracking-tight text-white uppercase font-heading leading-[1.05]">
                <span className="block text-white">JOHAR WALA</span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-white via-zinc-200 to-zinc-400">
                  OUTFIT.
                </span>
              </h1>
              <p className="mt-2 text-base sm:text-lg font-serif italic text-zinc-400 tracking-wide">
                — Outfit by hiituuu · Nandelav, Bharuch —
              </p>
            </div>

            <p className="text-base sm:text-lg text-zinc-300 max-w-2xl font-light leading-relaxed mb-8">
              A minimalist boutique portfolio showcasing limited-edition streetwear silhouettes,
              sculpted heavyweight textiles, and bespoke tailoring. We curate less so each piece makes an unmistakable statement.
            </p>

            {/* Swipe Up: Action Buttons & Location Hook */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.25, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 mb-10"
            >
              <a
                href="#store-location"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-bold text-black bg-white hover:bg-zinc-200 rounded-lg shadow-lg hover:shadow-white/10 transition-all active:scale-98"
              >
                <MapPin className="w-4 h-4 text-emerald-600 fill-emerald-600" />
                <span>View Store Map & Location</span>
              </a>

              <a
                href={STORE_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-bold text-white bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:opacity-95 rounded-lg shadow-md transition-all active:scale-98"
                title="Follow on Instagram @johar_walaoutfit"
              >
                <Instagram className="w-4 h-4 text-white" />
                <span>Instagram @johar_walaoutfit</span>
              </a>

              <a
                href={STORE_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-semibold text-white bg-zinc-900/90 hover:bg-zinc-800 border border-white/20 rounded-lg transition-all"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>WhatsApp</span>
              </a>
            </motion.div>

            {/* Quick Trust Markers / Store Specs */}
            <div className="pt-6 border-t border-white/10 grid grid-cols-2 sm:grid-cols-3 gap-4 text-left">
              <div>
                <span className="block text-[11px] font-mono uppercase tracking-wider text-zinc-500">Atelier Location</span>
                <span className="text-sm font-semibold text-zinc-200 block truncate" title={STORE_INFO.address}>
                  Shop 8, Al Noor Centre
                </span>
                <span className="text-xs text-zinc-400">Nandelav, Bharuch</span>
              </div>
              <div>
                <span className="block text-[11px] font-mono uppercase tracking-wider text-zinc-500">Direct Contact</span>
                <a href={`tel:${STORE_INFO.phone}`} className="text-sm font-semibold text-zinc-200 hover:underline block">
                  {STORE_INFO.displayPhone}
                </a>
                <span className="text-xs text-zinc-400">Calls & WhatsApp</span>
              </div>
              <a href="#timings" className="col-span-2 sm:col-span-1 p-2 -m-2 rounded-lg hover:bg-zinc-900/60 border border-transparent hover:border-emerald-500/20 transition-all block group">
                <span className="flex items-center justify-between text-[11px] font-mono uppercase tracking-wider text-zinc-400">
                  <span>Store Timings</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                </span>
                <span className="text-sm font-bold text-white group-hover:text-emerald-300 block font-mono tracking-tight mt-0.5">
                  9:00 AM – 8:00 PM
                </span>
                <span className="text-xs text-emerald-400 font-medium">Open All 7 Days · View Matrix →</span>
              </a>
            </div>
          </motion.div>

          {/* Right Column: Right-to-Left Animation */}
          <motion.div
            initial={{ opacity: 0, x: 60 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 relative"
          >
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Decorative framing element */}
              <div className="absolute -inset-2 bg-gradient-to-b from-white/10 via-transparent to-white/5 rounded-2xl blur-sm" />

              <div className="relative rounded-xl overflow-hidden border border-white/15 bg-zinc-950 shadow-2xl group">
                <img
                  src="/media/exact-store-rack.jpg"
                  alt="Johar Wala Outfit In-Store T-Shirt Rack - Shop No. 8 Al Noor Centre"
                  className="w-full h-[440px] sm:h-[500px] object-cover object-center group-hover:scale-102 transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                />

                {/* Dark gradient overlay for typography readability */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent pointer-events-none" />

                {/* Top Badge: Logo Watermark Overlay */}
                <div className="absolute top-4 left-4 z-20">
                  <div className="bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/15 flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-zinc-300" />
                    <span className="text-xs font-bold tracking-wider text-white uppercase font-heading">
                      Outfit by hiituuu
                    </span>
                  </div>
                </div>

                {/* Bottom Card Content with Direct Callout */}
                <div className="absolute bottom-0 inset-x-0 p-5 z-20 flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono uppercase tracking-widest text-zinc-400">
                      Bespoke Capsule Lookbook
                    </span>
                    <span className="text-xs font-medium text-emerald-400 bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded">
                      In Stock at Shop 8
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-white tracking-tight">
                    The Modern Streetwear Silhouette
                  </h3>
                  <p className="text-xs text-zinc-300 line-clamp-2">
                    Drop shoulders, heavyweight dense knit, and architectural utility bottoms customized for your frame in Bharuch.
                  </p>
                </div>
              </div>

              {/* Floating emblem card */}
              <div className="hidden sm:block absolute -bottom-5 -left-5 z-30">
                <BrandLogo variant="badge" />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
