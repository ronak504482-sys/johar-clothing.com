import React from 'react';
import { STORE_INFO } from '../data/storeData';

export const MarqueeBanner: React.FC = () => {
  const items = [
    `JOHAR WALA OUTFIT`,
    `TIMINGS: 9:00 AM TO 8:00 PM (OPEN ALL 7 DAYS)`,
    `Outfit by hiituuu`,
    `SHOP 8 AL NOOR SHOPPING CENTRE`,
    `NANDELAV, BHARUCH`,
    `DAILY 9 AM - 8 PM`,
    `CALL: ${STORE_INFO.displayPhone}`,
    `INSTAGRAM: ${STORE_INFO.instagramHandle}`,
    `BESPOKE TAILORING`,
    `CURATED CAPSULE 2026`,
  ];

  return (
    <div className="relative w-full overflow-hidden bg-black border-y border-white/10 py-3.5 select-none">
      <div className="flex w-max animate-marquee-left">
        {[...items, ...items, ...items].map((text, idx) => (
          <div key={idx} className="flex items-center mx-4">
            <span className="text-xs sm:text-sm font-bold tracking-widest text-zinc-300 uppercase whitespace-nowrap">
              {text}
            </span>
            <span className="text-zinc-600 mx-4 text-xs font-mono">✦</span>
          </div>
        ))}
      </div>
    </div>
  );
};
