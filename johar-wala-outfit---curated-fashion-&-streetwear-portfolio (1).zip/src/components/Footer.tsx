import React from 'react';
import { Phone, Instagram, MapPin, MessageCircle, ArrowUp } from 'lucide-react';
import { STORE_INFO } from '../data/storeData';
import { BrandLogo } from './BrandLogo';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-black border-t border-white/10 pt-16 pb-12 text-zinc-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          {/* Brand Info: Website Name highlighted in bold letters */}
          <div className="md:col-span-5 space-y-4">
            <BrandLogo variant="header" showSubtitle={false} />
            <p className="text-xs text-zinc-400 max-w-sm leading-relaxed">
              <strong className="text-white font-bold">Johar wala outfit</strong> — Curated limited-edition menswear & contemporary streetwear.
              Crafted under the creative direction of hiituuu in Bharuch, Gujarat.
            </p>
            <div className="pt-2 flex items-center gap-3">
              <a
                href={STORE_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-white/10 transition-colors"
                title="Instagram"
              >
                <Instagram className="w-4 h-4 text-pink-400" />
              </a>
              <a
                href={STORE_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-white/10 transition-colors"
                title="WhatsApp"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
              </a>
              <a
                href={`tel:${STORE_INFO.phone}`}
                className="p-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-white/10 transition-colors"
                title="Call"
              >
                <Phone className="w-4 h-4 text-zinc-300" />
              </a>
            </div>
          </div>

          {/* Quick Nav */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-widest text-white">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#store-location" className="hover:text-white transition-colors">
                  Store Map & Satellite View
                </a>
              </li>
              <li>
                <a href="#timings" className="hover:text-white transition-colors text-emerald-400 font-semibold">
                  Timings (9:00 AM – 8:00 PM)
                </a>
              </li>
              <li>
                <a href="#story" className="hover:text-white transition-colors">
                  The Story & hiituuu
                </a>
              </li>
              <li>
                <a href="#atelier" className="hover:text-white transition-colors">
                  In-Store Fit & Atelier
                </a>
              </li>
              <li>
                <a href="#location" className="hover:text-white transition-colors">
                  Store Location & Directions
                </a>
              </li>
              <li>
                <a
                  href={STORE_INFO.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors inline-flex items-center gap-1"
                >
                  <span>Instagram @johar_walaoutfit</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Location & Contact direct summary */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-widest text-white">
              Physical Atelier
            </h4>
            <div className="text-xs space-y-2 text-zinc-400">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <a
                  href={STORE_INFO.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors"
                >
                  Shop number 8, AL NOOR SHOPPING CENTRE, Chavaj Rd, Nandelav, Bharuch 392015 ↗
                </a>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-zinc-500 shrink-0" />
                <a href={`tel:${STORE_INFO.phone}`} className="hover:text-white">
                  +91 {STORE_INFO.phone}
                </a>
              </p>
              <p className="text-[11px] text-zinc-500 pl-6">
                Open All 7 Days: {STORE_INFO.hours}
              </p>
            </div>
          </div>
        </div>

        {/* Bottom copyright row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <p>
            © {new Date().getFullYear()} <strong className="text-zinc-300 font-bold">JOHAR WALA OUTFIT</strong>. Outfit by hiituuu. All rights reserved.
          </p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-zinc-400 hover:text-white transition-colors focus-visible:outline-none"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};
