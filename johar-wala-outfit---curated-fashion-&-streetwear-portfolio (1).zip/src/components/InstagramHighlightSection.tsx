import React from 'react';
import { motion } from 'motion/react';
import {
  Instagram,
  ExternalLink,
  Play,
  Heart,
  MessageCircle,
  Sparkles,
  MapPin,
  Clock,
  ArrowUpRight,
  Bookmark
} from 'lucide-react';
import { STORE_INFO, STORE_MEDIA_GALLERY } from '../data/storeData';

export const InstagramHighlightSection: React.FC = () => {
  return (
    <section id="instagram-spotlight" className="py-20 lg:py-24 bg-[#0a0a0d] border-b border-white/10 relative overflow-hidden">
      {/* Background glowing gradients */}
      <div className="absolute top-1/2 left-10 w-96 h-96 bg-rose-500/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-amber-500/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Tag */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-3xl mx-auto mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-rose-500/30 text-xs font-mono text-rose-300 mb-3">
            <Instagram className="w-3.5 h-3.5 text-pink-400" />
            <span>OFFICIAL INSTAGRAM COMMUNITY & REELS</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black uppercase text-white font-heading tracking-tight">
            FOLLOW <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-rose-500 to-purple-500">@JOHAR_WALAOUTFIT</span>
          </h2>
          <p className="mt-3 text-sm sm:text-base text-zinc-400 font-light">
            Follow our daily drops, fit checks, customer tailoring sessions, and live in-store walk-throughs recorded directly inside <strong className="text-white">Shop No. 8, Al Noor Shopping Centre, Bharuch</strong>.
          </p>
        </motion.div>

        {/* Profile Card Header Component */}
        <div className="p-6 sm:p-8 bg-zinc-950/80 rounded-2xl border border-white/15 backdrop-blur-md shadow-2xl mb-12">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            {/* Left: Avatar & Bio */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start text-center sm:text-left gap-5">
              {/* Instagram Gradient Ring Avatar */}
              <div className="p-1 rounded-full bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 shrink-0 shadow-lg shadow-rose-500/20">
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-black flex flex-col items-center justify-center border-2 border-black p-2">
                  <span className="font-heading font-black text-white text-xs sm:text-sm tracking-wider uppercase text-center leading-tight">
                    JOHAR WALA
                  </span>
                  <span className="text-[10px] text-zinc-400 font-serif italic">
                    hiituuu
                  </span>
                </div>
              </div>

              {/* Bio & Handle */}
              <div>
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5">
                  <h3 className="text-xl sm:text-2xl font-black text-white font-heading">
                    {STORE_INFO.instagramHandle}
                  </h3>
                  <span className="px-2 py-0.5 rounded-md bg-white/10 text-zinc-300 text-[11px] font-mono font-medium">
                    Boutique Atelier
                  </span>
                </div>

                <p className="text-sm font-semibold text-zinc-200 mt-1">
                  Johar wala outfit · {STORE_INFO.brandSubtitle}
                </p>

                <p className="text-xs text-zinc-400 mt-1 max-w-xl leading-relaxed">
                  📍 Shop No. 8, AL NOOR SHOPPING CENTRE, NANDELAV, BHARUCH, GUJARAT<br />
                  🕒 Daily: 9:00 AM – 8:00 PM (Open 7 Days) | WhatsApp: +91 63537 90321
                </p>
              </div>
            </div>

            {/* Right: Primary Instagram Call To Action */}
            <div className="flex flex-col sm:flex-row md:flex-col items-stretch gap-2.5 w-full md:w-auto shrink-0">
              <a
                href={STORE_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="py-3 px-6 rounded-xl bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:opacity-95 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-rose-500/25 transition-all active:scale-95"
              >
                <Instagram className="w-4 h-4 text-white" />
                <span>Follow on Instagram</span>
                <ArrowUpRight className="w-4 h-4 text-white/80" />
              </a>

              <a
                href={STORE_INFO.instagramReelUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2.5 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-white/10 font-medium text-xs flex items-center justify-center gap-2 transition-colors"
              >
                <Play className="w-3.5 h-3.5 fill-rose-400 text-rose-400" />
                <span>Open Featured Reel</span>
              </a>
            </div>
          </div>
        </div>

        {/* Highlighted Reels & In-Store Media Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Reel Card 1: The Requested Instagram Reel DTuKt55iMI6 */}
          <div className="bg-zinc-950 rounded-2xl border border-rose-500/40 hover:border-rose-400 overflow-hidden shadow-xl flex flex-col justify-between group transition-all">
            <div className="relative aspect-[9/14] bg-zinc-900 overflow-hidden">
              <img
                src="/media/video-wideleg-baggy.jpg"
                alt="Instagram Reel DTuKt55iMI6 - Wideleg Baggy Denim Drop"
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/20" />

              {/* Top Reel Badge */}
              <div className="absolute top-3 inset-x-3 flex items-center justify-between z-10">
                <span className="px-2.5 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider bg-rose-950/90 border border-rose-500/50 text-rose-300 flex items-center gap-1.5 shadow-md">
                  <Play className="w-3 h-3 fill-rose-300" />
                  <span>Featured Reel</span>
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono text-zinc-300 bg-black/80">
                  @johar_walaoutfit
                </span>
              </div>


              {/* Bottom Details */}
              <div className="absolute bottom-3 inset-x-3 z-10">
                <span className="text-[10px] font-mono uppercase text-emerald-400 block mb-0.5">
                  DENIM & BOTTOMS · BHARUCH
                </span>
                <h4 className="text-base font-bold text-white leading-snug">
                  Wideleg Baggy Denim Reel
                </h4>
                <p className="text-xs text-zinc-300 mt-1 line-clamp-2">
                  Viral reel showcasing heavy skater drape and whiskered denim finishes at Shop No. 8.
                </p>
              </div>
            </div>

            <div className="p-4 bg-zinc-950 flex items-center justify-between border-t border-white/10">
              <a
                href={STORE_INFO.instagramReelUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2 px-3 text-xs font-bold rounded-lg bg-white text-black hover:bg-zinc-200 transition-colors flex items-center justify-center gap-1.5"
              >
                <Instagram className="w-3.5 h-3.5 text-black" />
                <span>Watch Reel on IG</span>
                <ExternalLink className="w-3 h-3 text-black/70" />
              </a>
            </div>
          </div>

          {/* Reel Card 2: Asthetic Bonkers Pants */}
          <div className="bg-zinc-950 rounded-2xl border border-white/15 hover:border-white/30 overflow-hidden shadow-xl flex flex-col justify-between group transition-all">
            <div className="relative aspect-[9/14] bg-zinc-900 overflow-hidden">
              <img
                src="/media/video-bonkers-pants.jpg"
                alt="Asthetic Bonkers Pants Reel"
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/20" />

              <div className="absolute top-3 inset-x-3 flex items-center justify-between z-10">
                <span className="px-2.5 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider bg-black/80 border border-white/20 text-white flex items-center gap-1.5">
                  <Play className="w-3 h-3 fill-emerald-400 text-emerald-400" />
                  <span>Reel Video</span>
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono text-zinc-300 bg-black/80">
                  Shop #8 Video
                </span>
              </div>


              <div className="absolute bottom-3 inset-x-3 z-10">
                <span className="text-[10px] font-mono uppercase text-emerald-400 block mb-0.5">
                  5 COLORWAYS · FRENCH TERRY
                </span>
                <h4 className="text-base font-bold text-white leading-snug">
                  Asthetic Bonkers Pants Drop
                </h4>
                <p className="text-xs text-zinc-300 mt-1 line-clamp-2">
                  Heavyweight lounge and street trousers with thick drawstrings and relaxed drape.
                </p>
              </div>
            </div>

            <div className="p-4 bg-zinc-950 flex items-center justify-between border-t border-white/10">
              <a
                href={STORE_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg bg-zinc-900 hover:bg-zinc-800 text-white border border-white/10 transition-colors flex items-center justify-center gap-1.5"
              >
                <Instagram className="w-3.5 h-3.5 text-pink-400" />
                <span>View on @johar_walaoutfit</span>
              </a>
            </div>
          </div>

          {/* Reel Card 3: Asthetic Shop Tour */}
          <div className="bg-zinc-950 rounded-2xl border border-white/15 hover:border-white/30 overflow-hidden shadow-xl flex flex-col justify-between group transition-all sm:col-span-2 lg:col-span-1">
            <div className="relative aspect-[9/14] bg-zinc-900 overflow-hidden">
              <img
                src="/media/video-aesthetic-shop.jpg"
                alt="Asthetic Shop Showroom Tour"
                className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/20" />

              <div className="absolute top-3 inset-x-3 flex items-center justify-between z-10">
                <span className="px-2.5 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider bg-black/80 border border-white/20 text-white flex items-center gap-1.5">
                  <Play className="w-3 h-3 fill-emerald-400 text-emerald-400" />
                  <span>Showroom Reel</span>
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono text-zinc-300 bg-black/80">
                  Al Noor Centre
                </span>
              </div>


              <div className="absolute bottom-3 inset-x-3 z-10">
                <span className="text-[10px] font-mono uppercase text-emerald-400 block mb-0.5">
                  STORE TOUR · SHOP NO. 8
                </span>
                <h4 className="text-base font-bold text-white leading-snug">
                  Asthetic Shop Walkthrough
                </h4>
                <p className="text-xs text-zinc-300 mt-1 line-clamp-2">
                  Checkerboard checkout counter, turf trim, denim shelves, and spotlight interior.
                </p>
              </div>
            </div>

            <div className="p-4 bg-zinc-950 flex items-center justify-between border-t border-white/10">
              <a
                href={STORE_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2 px-3 text-xs font-semibold rounded-lg bg-zinc-900 hover:bg-zinc-800 text-white border border-white/10 transition-colors flex items-center justify-center gap-1.5"
              >
                <Instagram className="w-3.5 h-3.5 text-pink-400" />
                <span>Visit Instagram Page</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
