import React from 'react';
import { motion } from 'motion/react';
import { Clock, CheckCircle, Calendar, ShieldCheck, Sparkles, MapPin, Phone, MessageCircle } from 'lucide-react';
import { StoreTimingColumn } from './StoreTimingColumn';
import { STORE_INFO } from '../data/storeData';

export const TimingSection: React.FC = () => {
  return (
    <section id="timings" className="py-20 lg:py-28 bg-[#09090b] relative overflow-hidden border-b border-white/10">
      {/* Background radial gradient glow */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[500px] h-[500px] bg-emerald-500/[0.03] blur-[140px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header: Swipe Down Animation */}
        <motion.div
          initial={{ opacity: 0, y: -25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="text-center max-w-3xl mx-auto mb-14"
        >
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-zinc-900 border border-emerald-500/30 text-xs font-mono text-zinc-300 mb-3 shadow-[0_0_15px_rgba(16,185,129,0.1)]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="uppercase tracking-widest text-emerald-300 font-semibold">STORE & WEBSITE TIMINGS</span>
            <span className="text-zinc-600">·</span>
            <span className="text-zinc-400 font-medium">9:00 AM – 8:00 PM</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-black uppercase text-white font-heading tracking-tight">
            OPERATING HOURS & TIMINGS
          </h2>

          <p className="mt-3 text-sm sm:text-base text-zinc-400 font-light">
            Plan your visit to <strong className="text-white font-bold">JOHAR WALA OUTFIT</strong> at Shop No. 8, Al Noor Shopping Centre, Nandelav.
            Our boutique and consultation doors are open every single day from <strong>9:00 AM to 8:00 PM</strong>.
          </p>
        </motion.div>

        {/* 2-Column Grid: Left Column is the Dedicated Eye-Catching Timing Column (Swipe Left-to-Right), Right Column is Visiting Perks & Fitting Slots (Swipe Right-to-Left) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          {/* Dedicated Eye Catching Timing Column: Left-to-Right Animation */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 flex flex-col"
          >
            <StoreTimingColumn variant="featured" className="h-full" />
          </motion.div>

          {/* Right Accompanying Column: Right-to-Left Animation */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 flex flex-col justify-between space-y-6"
          >
            {/* Quick Summary Card */}
            <div className="p-6 sm:p-7 bg-zinc-950 rounded-2xl border border-white/10 shadow-xl space-y-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white border border-white/10">
                  <Calendar className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <span className="text-[11px] font-mono uppercase tracking-wider text-zinc-500 block">Weekly Commitment</span>
                  <h3 className="text-lg font-bold text-white uppercase font-heading">
                    Open All 7 Days
                  </h3>
                </div>
              </div>

              <div className="space-y-3 text-xs text-zinc-300">
                <div className="p-3.5 rounded-xl bg-zinc-900/80 border border-white/5 flex items-start gap-3">
                  <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white block">Morning Walk-Ins (9:00 AM – 1:00 PM)</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block mt-0.5">
                      Ideal for relaxed garment trials, fabric inspections, and quiet browsing of our 4 curated drop pieces.
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-zinc-900/80 border border-white/5 flex items-start gap-3">
                  <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white block">Afternoon & Evening Atelier (1:00 PM – 8:00 PM)</span>
                    <span className="text-zinc-400 text-[11px] leading-relaxed block mt-0.5">
                      Full custom hemming, bespoke sizing consultations with hiituuu, and new collection releases.
                    </span>
                  </div>
                </div>
              </div>

              {/* Direct Booking Hook */}
              <div className="pt-2">
                <a
                  href={`https://wa.me/${STORE_INFO.whatsappNumber}?text=${encodeURIComponent(
                    'Hi hiituuu, I would like to visit Johar Wala Outfit between 9:00 AM and 8:00 PM today.'
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white font-semibold text-xs border border-white/15 transition-all shadow-md"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-400" />
                  <span>Notify hiituuu Before You Arrive</span>
                </a>
              </div>
            </div>

            {/* In-Store Quick Reference Card */}
            <div className="p-5 bg-zinc-950/80 rounded-2xl border border-white/10 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-mono uppercase tracking-wider text-zinc-400">Atelier Direct Contact</span>
                <span className="text-emerald-400 font-medium">9 AM to 8 PM Live</span>
              </div>

              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-zinc-400" />
                  <a href={`tel:${STORE_INFO.phone}`} className="text-sm font-bold text-white hover:underline">
                    {STORE_INFO.displayPhone}
                  </a>
                </div>
                <a
                  href={`tel:${STORE_INFO.phone}`}
                  className="text-xs px-3 py-1.5 rounded-lg bg-white text-black font-semibold hover:bg-zinc-200 transition-colors"
                >
                  Dial Now
                </a>
              </div>

              <p className="text-[11px] text-zinc-500 pt-1 border-t border-white/5 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                <span>Shop 8, Al Noor Shopping Centre, Nandelav, Bharuch</span>
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
