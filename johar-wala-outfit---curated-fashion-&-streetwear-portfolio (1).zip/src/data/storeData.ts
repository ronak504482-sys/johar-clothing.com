export interface ShowcaseItem {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  fabric: string;
  gsm: string;
  color: string;
  fit: string;
  sizes: string[];
  description: string;
  details: string[];
  image: string;
  badge?: string;
  mediaType?: 'image' | 'video';
  videoPreview?: string;
  reelUrl?: string;
  instagramReelId?: string;
  inStoreLocation?: string;
}

export interface StoreMediaGalleryItem {
  id: string;
  title: string;
  subtitle: string;
  type: 'image' | 'video';
  mediaUrl: string;
  caption: string;
  category: string;
  badge: string;
  duration?: string;
}

export const STORE_INFO = {
  name: "Johar wala outfit",
  founder: "hiituuu",
  brandSubtitle: "Outfit by hiituuu",
  address: "Shop number 8, AL NOOR SHOPPING CENTRE, Chavaj Rd, NANDELAV, BHARUCH, GUJARAT 392015, INDIA",
  shortAddress: "Shop No. 8, Al Noor Shopping Centre, Chavaj Rd, Nandelav, Bharuch",
  phone: "6353790321",
  displayPhone: "+91 63537 90321",
  whatsappNumber: "916353790321",
  whatsappUrl: "https://wa.me/916353790321?text=Hello%20Johar%20Wala%20Outfit%2C%20I%20would%20like%20to%20inquire%20about%20your%20collection.",
  instagramUrl: "https://www.instagram.com/johar_walaoutfit?utm_source=ig_web_button_share_sheet&stkn=ZDNlZDc0MzIxNw==",
  instagramHandle: "@johar_walaoutfit",
  instagramReelUrl: "https://www.instagram.com/reel/DTuKt55iMI6/?utm_source=ig_web_copy_link&stkn=MzRlODBiNWFlZA==",
  googleMapsUrl: "https://maps.app.goo.gl/futht1AMsVXocAx29",
  googleMapsDirectionsUrl: "https://www.google.com/maps/dir/?api=1&destination=21.7279774,72.9997579",
  googleMapsEmbedUrl: "https://maps.google.com/maps?q=21.7279774,72.9997579&t=k&z=19&ie=UTF8&iwloc=&output=embed",
  googleMapsSatelliteEmbedUrl: "https://maps.google.com/maps?q=21.7279774,72.9997579&t=k&z=19&ie=UTF8&iwloc=&output=embed",
  googleMapsRoadmapEmbedUrl: "https://maps.google.com/maps?q=21.7279774,72.9997579&t=&z=19&ie=UTF8&iwloc=&output=embed",
  coordinates: {
    lat: 21.7279774,
    lng: 72.9997579
  },
  landmarks: [
    "Al Noor Shopping Centre, Chavaj Rd, Nandelav, Bharuch",
    "3.2 km (approx. 8 minutes) from Bharuch Railway Junction",
    "Customer parking available inside Al Noor Shopping complex",
    "Private in-store trial room with full-length studio mirrors"
  ],
  hours: "9:00 AM – 8:00 PM",
  days: "Open All 7 Days (Mon - Sun)",
  openHour: 9,
  closeHour: 20,
  timingBadge: "9:00 AM to 8:00 PM",
  city: "Bharuch, Gujarat",
};

// Real In-Store Photo & Video Showcase Gallery
export const STORE_MEDIA_GALLERY: StoreMediaGalleryItem[] = [
  {
    id: "reel-aesthetic-shop",
    title: "Asthetic Shop Boutique Walkthrough",
    subtitle: "Johar Wala Outfit · Bharuch Gujarat",
    type: "video",
    mediaUrl: "/media/video-aesthetic-shop.jpg",
    caption: "Full tour of our studio at Shop 8, Al Noor Centre featuring checkerboard checkout counter, stacked denim racks, front window display tees, and atmospheric studio lighting.",
    category: "Store Walkthrough",
    badge: "Official Video Reel",
    duration: "0:23 Reel"
  },
  {
    id: "reel-bonkers-pants",
    title: "Asthetic Bonkers Streetwear Bottoms",
    subtitle: "Relaxed Fit Sweatpants & Trousers",
    type: "video",
    mediaUrl: "/media/video-bonkers-pants.jpg",
    caption: "Live showcase of the Asthetic Bonkers pants line in 5 essential colors (Jet Black, Camel Beige, Navy Slate, Heather Grey, and Pure White) with ribbed waistband and premium drape.",
    category: "Pants Collection",
    badge: "Featured Reel",
    duration: "0:25 Reel"
  },
  {
    id: "reel-wideleg-baggy",
    title: "Wideleg Baggy Denim Showcase",
    subtitle: "Heavyweight Baggy Jeans & Pants",
    type: "video",
    mediaUrl: "/media/video-wideleg-baggy.jpg",
    caption: "In-store spotlight on our wideleg baggy denim series: vintage whiskered fades, acid wash grey, deep midnight black, and straight wide-cut silhouettes hanging at Shop No. 8.",
    category: "Denim & Bottoms",
    badge: "Trending Reel",
    duration: "0:38 Reel"
  },
  {
    id: "photo-rack-tees",
    title: "Curated Boxy & Raglan Tees Wall",
    subtitle: "Two-Tier In-Store Hanger System",
    type: "image",
    mediaUrl: "/media/rack-tee-collection.jpg",
    caption: "Upper and lower hanging rows displaying color-blocked raglan tees (racing green, scarlet red, jet black), oversized graphic tees, and earth-toned drop shirts at Shop No. 8.",
    category: "In-Store Racks",
    badge: "Store Photograph"
  },
  {
    id: "photo-graphic-longsleeves",
    title: "Gothic & Flame Long-Sleeve Rack",
    subtitle: "Artisanal Sleeve Prints & Occult Graphics",
    type: "image",
    mediaUrl: "/media/rack-graphic-longsleeves.jpg",
    caption: "Signature collection of long-sleeve statement pieces: spiderweb arm motifs, flame typography, bone and serpent prints, and intricate gothic white chandeliers on heavy knits.",
    category: "Statement Pieces",
    badge: "Store Photograph"
  }
];

export const SHOWCASE_COLLECTION: ShowcaseItem[] = [
  {
    id: "wideleg-baggy-denim",
    name: "The Wideleg Baggy Denim Drop",
    category: "Denim & Bottoms",
    price: 1999,
    originalPrice: 2499,
    fabric: "100% Rigid Heavyweight Japanese Denim Twill",
    gsm: "360 GSM",
    color: "Washed Acid Slate & Midnight Whiskered Black",
    fit: "Ultra-Relaxed Wide-Leg Baggy Silhouette",
    sizes: ["28", "30", "32", "34", "36"],
    description:
      "As seen in our viral in-store Bharuch reel: true wide-leg skater drape, deep front whiskering, clean ankle break for sneakers, and heavy bar-tacked pockets. Custom waist calibration available in-store.",
    details: [
      "Heavyweight 360 GSM rigid denim that holds dramatic structural wide drape",
      "Authentic hand-finished whiskering and vintage fade wash",
      "Reinforced heavy pocket bags and YKK metal hardware",
      "Free in-store waist and length hemming at Shop No. 8 by hiituuu"
    ],
    image: "/media/video-wideleg-baggy.jpg",
    badge: "Official IG Reel",
    mediaType: "video",
    videoPreview: "/media/video-wideleg-baggy.jpg",
    reelUrl: "https://www.instagram.com/reel/DTuKt55iMI6/?utm_source=ig_web_copy_link&stkn=MzRlODBiNWFlZA==",
    instagramReelId: "DTuKt55iMI6",
    inStoreLocation: "Denim Hanging Bar · Section A"
  },
  {
    id: "asthetic-bonkers-pants",
    name: "Asthetic Bonkers Relaxed Trousers",
    category: "Lounge & Street Utility",
    price: 1599,
    originalPrice: 1999,
    fabric: "High-Density French Terry Loopback Cotton",
    gsm: "340 GSM",
    color: "Camel Tan, Slate Navy, Heather Grey & Jet Black",
    fit: "Straight Wide-Cut with Drawstring Waistband",
    sizes: ["S", "M", "L", "XL", "XXL"],
    description:
      "Featured in our 'Asthetic Bonkers (Bharuch | Gujarat)' video: heavy drape lounge trousers with thick elasticated waistband, chunky tonal drawstrings, and signature arched Bonkers leg embroidery.",
    details: [
      "Ultra-soft 340 GSM compact cotton loopback with zero pilling",
      "Thick elastic waistband with premium woven cotton drawcords",
      "Deep concealed side pockets and clean straight-cut cuff",
      "Available across 5 versatile colorways at the studio"
    ],
    image: "/media/video-bonkers-pants.jpg",
    badge: "As Seen On Reel",
    mediaType: "video",
    videoPreview: "/media/video-bonkers-pants.jpg",
    inStoreLocation: "Hanger Rail · Section B"
  },
  {
    id: "gothic-longsleeve-capsule",
    name: "Gothic Spiderweb & Flame Long-Sleeve",
    category: "Graphic Knitwear",
    price: 1399,
    originalPrice: 1799,
    fabric: "100% Combed Heavy Cotton Jersey",
    gsm: "260 GSM",
    color: "Spiderweb White & Chandelier Jet Black",
    fit: "Relaxed Drop-Shoulder Long-Sleeve Cut",
    sizes: ["M", "L", "XL", "XXL"],
    description:
      "Captured live on our studio racks: full sleeve screen-printed gothic spiderwebs, occult chandelier illustrations, dragon flames, and snake motifs on heavyweight combed cotton.",
    details: [
      "260 GSM breathable high-density combed cotton knit",
      "Silkscreen printed sleeve and chest art with high-opacity inks",
      "Ribbed comfort cuffs and reinforced collar band",
      "Handcrafted in limited batches by hiituuu at Shop No. 8"
    ],
    image: "/media/rack-graphic-longsleeves.jpg",
    badge: "In-Store Exclusive",
    mediaType: "image",
    inStoreLocation: "Front Display Rack"
  },
  {
    id: "vintage-raglan-boxy-tee",
    name: "Vintage Contrast Raglan & Boxy Tee",
    category: "Heavyweight Knitwear",
    price: 1199,
    originalPrice: 1499,
    fabric: "100% Organic Super-Combed Cotton",
    gsm: "280 GSM",
    color: "Forest Green/White & Scarlet Red/Chalk",
    fit: "Athletic Drop Raglan Silhouette",
    sizes: ["S", "M", "L", "XL"],
    description:
      "Featured on our studio's top tier display rack: contrast raglan baseball sleeves, retro typography, and an oversized boxy torso that drapes naturally without clinging.",
    details: [
      "280 GSM heavy interlock cotton knit with plush soft finish",
      "Double-stitched contrast raglan shoulder seams",
      "Heavy ribbed neckline that retains shape after endless washes",
      "Custom fit consultation with hiituuu upon visiting"
    ],
    image: "/media/exact-store-rack.jpg",
    badge: "Boutique Essential",
    mediaType: "image",
    inStoreLocation: "Upper Wall Rack · Tier 1"
  }
];

export const BRAND_VALUES = [
  {
    title: "Curated Drops Over Mass Racks",
    desc: "We deliberately showcase only a handful of master-crafted silhouettes per drop. No overwhelming racks, no fast-fashion clones—only pieces worth owning."
  },
  {
    title: "Heavyweight Luxury Textiles",
    desc: "Every garment uses custom-milled 280 to 420 GSM fabrics designed to drape with weight and retain their structure season after season."
  },
  {
    title: "In-Store Fit Atelier by hiituuu",
    desc: "Visit Shop #8 at Al Noor Shopping Centre for custom sizing adjustments, length hem adjustments, and personal silhouette recommendations."
  }
];

export const CLIENT_TESTIMONIALS = [
  {
    quote: "Finding high-grade heavyweight boxy tees and wideleg pants in Bharuch was impossible until Johar Wala Outfit opened. The drape and wash are top tier.",
    author: "Zaid Patel",
    location: "Bharuch",
    item: "Wideleg Baggy Denim"
  },
  {
    quote: "hiituuu personally tailored the cargo fit for me at Shop #8 Al Noor. The stitching quality, pocket depth, and material feel are leagues ahead of online brands.",
    author: "Faisal Sheikh",
    location: "Nandelav, Bharuch",
    item: "Nandelav Utility Cargo"
  },
  {
    quote: "The Bonkers aesthetic sweatpants are crazy comfortable. Picked up two colors from the studio. Definitely the best boutique in Bharuch.",
    author: "Mohammad Vohra",
    location: "Ankleshwar / Bharuch",
    item: "Asthetic Bonkers Trousers"
  }
];
