import React, { useState } from 'react';
import { Phone, MessageCircle, Instagram, Menu, X, MapPin } from 'lucide-react';
import { STORE_INFO } from '../data/storeData';
import { BrandLogo } from './BrandLogo';

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Shop Location & Map', href: '#store-location', icon: MapPin },
    { label: 'Instagram @johar_walaoutfit', href: STORE_INFO.instagramUrl, highlight: true, icon: Instagram, external: true },
    { label: 'Store Timings (9AM-8PM)', href: '#timings' },
    { label: 'hiituuu Atelier', href: '#story' },
    { label: 'Contact', href: '#location' }
  ];

  return (
    <header className="sticky top-0 z-50 w-full bg-[#08080a]/90 backdrop-blur-md border-b border-white/10 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Zone 1: Brand Wordmark (Highlighted in bold letters) */}
        <a href="#" className="flex items-center gap-3 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white">
          <BrandLogo variant="header" />
        </a>

        {/* Zone 2: Clean Text Nav Links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-zinc-300">
          {navLinks.map((link) => {
            const Icon = link.icon;
            return (
              <a
                key={link.label}
                href={link.href}
                target={link.external ? '_blank' : undefined}
                rel={link.external ? 'noopener noreferrer' : undefined}
                className={`flex items-center gap-1.5 transition-colors duration-200 py-1 ${
                  link.highlight
                    ? 'text-rose-300 hover:text-white font-semibold'
                    : 'text-zinc-300 hover:text-white'
                }`}
              >
                {Icon && <Icon className={`w-3.5 h-3.5 ${link.highlight ? 'text-pink-400' : 'text-zinc-400'}`} />}
                <span>{link.label}</span>
              </a>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="hidden sm:flex items-center gap-3">
          {/* Quick Timing Pill */}
          <a
            href="#timings"
            className="hidden xl:flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-zinc-200 bg-zinc-900/90 hover:bg-zinc-800 border border-emerald-500/30 rounded-lg transition-all"
            title="Website & Store Timings: 9:00 AM - 8:00 PM"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-zinc-300">9 AM – 8 PM</span>
            <span className="text-[10px] text-emerald-400 font-mono uppercase bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-500/20">Open 7 Days</span>
          </a>

          {/* Quick Call */}
          <a
            href={`tel:${STORE_INFO.phone}`}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-zinc-200 hover:text-white bg-zinc-900/80 hover:bg-zinc-800 border border-white/10 rounded-lg transition-all whitespace-nowrap"
            title="Call Store"
          >
            <Phone className="w-3.5 h-3.5 text-zinc-400" />
            <span>{STORE_INFO.displayPhone}</span>
          </a>

          {/* WhatsApp Direct Action */}
          <a
            href={STORE_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-black bg-white hover:bg-zinc-200 rounded-lg shadow-sm transition-all whitespace-nowrap active:scale-95"
          >
            <MessageCircle className="w-3.5 h-3.5 text-black fill-black" />
            <span>Chat on WhatsApp</span>
          </a>
        </div>

        {/* Mobile Hamburger Toggle */}
        <div className="flex sm:hidden items-center gap-2">
          <a
            href={STORE_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 text-black bg-white rounded-lg active:scale-95"
            aria-label="WhatsApp"
          >
            <MessageCircle className="w-4 h-4 fill-black" />
          </a>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-zinc-300 hover:text-white rounded-lg bg-zinc-900 border border-white/10 focus-visible:outline-none"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown with Swipe-down feel */}
      {mobileMenuOpen && (
        <div className="sm:hidden border-b border-white/10 bg-[#09090b] px-4 pt-3 pb-6 space-y-4 animate-in slide-in-from-top duration-200">
          <div className="flex flex-col space-y-3">
            {navLinks.map((link) => {
              const Icon = link.icon;
              return (
                <a
                  key={link.label}
                  href={link.href}
                  target={link.external ? '_blank' : undefined}
                  rel={link.external ? 'noopener noreferrer' : undefined}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`text-base font-medium px-2 py-2 rounded-md flex items-center justify-between transition-colors ${
                    link.highlight
                      ? 'text-rose-300 bg-rose-950/30 border border-rose-500/20'
                      : 'text-zinc-300 hover:text-white hover:bg-zinc-900'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {Icon && <Icon className={`w-4 h-4 ${link.highlight ? 'text-pink-400' : 'text-zinc-400'}`} />}
                    <span>{link.label}</span>
                  </div>
                  {link.highlight && <Instagram className="w-4 h-4 text-pink-400" />}
                </a>
              );
            })}
          </div>

          <div className="pt-4 border-t border-white/10 flex flex-col gap-2.5">
            <div className="p-3 bg-zinc-900/90 rounded-lg border border-emerald-500/30 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-zinc-300 font-medium">Timings:</span>
                <span className="text-white font-bold font-mono">9:00 AM – 8:00 PM</span>
              </div>
              <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-500/20 uppercase font-mono">
                Open 7 Days
              </span>
            </div>

            <div className="text-xs text-zinc-400 flex items-center gap-1.5 px-2">
              <MapPin className="w-3.5 h-3.5 text-zinc-500" />
              <span>Shop 8, Al Noor Shopping Centre, Nandelav, Bharuch</span>
            </div>
            <a
              href={`tel:${STORE_INFO.phone}`}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-semibold text-white bg-zinc-900 border border-white/15 rounded-lg"
            >
              <Phone className="w-3.5 h-3.5 text-zinc-400" />
              <span>Call: {STORE_INFO.displayPhone}</span>
            </a>
            <a
              href={STORE_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-bold text-black bg-white rounded-lg"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-black" />
              <span>Inquire via WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
