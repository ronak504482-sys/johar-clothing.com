import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  MapPin,
  Phone,
  Instagram,
  Clock,
  Navigation,
  Copy,
  Check,
  MessageCircle,
  ExternalLink,
  Send
} from 'lucide-react';
import { STORE_INFO } from '../data/storeData';

export const LocationSection: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [formName, setFormName] = useState('');
  const [formQuery, setFormQuery] = useState('');

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(STORE_INFO.address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formQuery.trim()) return;
    const text = encodeURIComponent(
      `Hi hiituuu, my name is ${formName || 'Customer'}. Inquiry: ${formQuery}`
    );
    window.open(`https://wa.me/${STORE_INFO.whatsappNumber}?text=${text}`, '_blank');
  };

  return (
    <section id="location" className="py-20 lg:py-28 bg-[#09090b] relative overflow-hidden border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Swipe Down: Section Heading */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-white/10 text-xs font-mono text-zinc-400 mb-3">
            <MapPin className="w-3.5 h-3.5 text-zinc-400" />
            <span>NANDELAV · BHARUCH · GUJARAT</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black uppercase text-white font-heading tracking-tight">
            VISIT <strong className="text-white">JOHAR WALA OUTFIT</strong>
          </h2>
          <p className="mt-3 text-base text-zinc-400 font-light">
            Drop by our physical store at Al Noor Shopping Centre to test fabrics, try the cuts in person, or get custom tailoring.
          </p>
        </motion.div>

        {/* 2-Column Split: Left Contact & Location Details (Left-to-Right) vs Right Map & Direct Inquiry (Right-to-Left) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          {/* Left Column: Left-to-Right Animation */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex flex-col justify-between space-y-6"
          >
            {/* Address Card */}
            <div className="p-6 sm:p-8 bg-zinc-950 rounded-2xl border border-white/15 shadow-xl">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <span className="text-xs font-mono uppercase tracking-widest text-zinc-500">
                    Boutique Address
                  </span>
                  <h3 className="text-xl sm:text-2xl font-bold text-white mt-1">
                    Shop Number 8, AL NOOR SHOPPING CENTRE
                  </h3>
                  <p className="text-sm text-zinc-300 font-medium mt-1">
                    Chavaj Rd, Nandelav, Bharuch, Gujarat 392015
                  </p>
                </div>
                <button
                  onClick={handleCopyAddress}
                  className="p-2.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-white/10 transition-colors shrink-0"
                  title="Copy full address"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              <div className="text-xs text-zinc-400 space-y-1.5 pb-6 border-b border-white/10">
                <p>• Landmark: Al Noor Shopping Centre complex, Chavaj Rd, Nandelav</p>
                <p>• Parking: Ample customer parking available at the complex</p>
                <p>• Trial Room: Private fitting area with studio mirrors</p>
              </div>

              {/* Action Buttons for Address */}
              <div className="pt-6 flex flex-wrap gap-3">
                <a
                  href={STORE_INFO.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-white text-black font-bold text-xs shadow-md hover:bg-zinc-200 transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Open in Google Maps</span>
                </a>
                <button
                  onClick={handleCopyAddress}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white font-medium text-xs border border-white/10 transition-colors"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Address Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Address</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Direct Connect Hub */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Phone Dial */}
              <div className="p-5 bg-zinc-950 rounded-xl border border-white/10 flex flex-col justify-between">
                <div>
                  <span className="text-[11px] font-mono uppercase tracking-wider text-zinc-500">Direct Phone</span>
                  <h4 className="text-lg font-bold text-white mt-1">6353790321</h4>
                  <p className="text-xs text-zinc-400 mt-0.5">Calls & WhatsApp active</p>
                </div>
                <div className="pt-4 mt-2 border-t border-white/5 flex gap-2">
                  <a
                    href={`tel:${STORE_INFO.phone}`}
                    className="flex-1 py-2 px-3 text-center text-xs font-semibold bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg border border-white/10 transition-colors"
                  >
                    Call Now
                  </a>
                  <a
                    href={STORE_INFO.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2 px-3 text-center text-xs font-semibold bg-emerald-950/60 hover:bg-emerald-900/80 text-emerald-400 rounded-lg border border-emerald-500/20 transition-colors flex items-center justify-center"
                    title="WhatsApp"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Instagram Feed / Handle */}
              <div className="p-5 bg-zinc-950 rounded-xl border border-white/10 flex flex-col justify-between">
                <div>
                  <span className="text-[11px] font-mono uppercase tracking-wider text-zinc-500">Instagram Handle</span>
                  <h4 className="text-base font-bold text-white mt-1 truncate">@johar_walaoutfit</h4>
                  <p className="text-xs text-zinc-400 mt-0.5">Daily fits & drop announcements</p>
                </div>
                <div className="pt-4 mt-2 border-t border-white/5">
                  <a
                    href={STORE_INFO.instagramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-3 text-center text-xs font-semibold bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg border border-white/10 transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Instagram className="w-3.5 h-3.5 text-pink-400" />
                    <span>View Profile</span>
                    <ExternalLink className="w-3 h-3 text-zinc-500" />
                  </a>
                </div>
              </div>
            </div>

            {/* Operating Hours Banner */}
            <div className="p-4 bg-zinc-950 rounded-xl border border-emerald-500/30 flex items-center justify-between text-xs shadow-lg">
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-emerald-400" />
                <div>
                  <span className="text-white font-semibold">Store Timings: </span>
                  <span className="text-white font-bold font-mono">9:00 AM – 8:00 PM</span>
                  <span className="text-zinc-400 block text-[11px]">Open Mon through Sun</span>
                </div>
              </div>
              <span className="text-emerald-300 font-bold bg-emerald-950/80 border border-emerald-500/40 px-2.5 py-1 rounded text-[11px] font-mono tracking-wide">
                9 AM – 8 PM
              </span>
            </div>
          </motion.div>

          {/* Right Column: Right-to-Left Animation (Stylized Map & Quick Inquiry) */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 flex flex-col justify-between space-y-6"
          >
            {/* Interactive Working Map */}
            <div className="bg-zinc-950 rounded-2xl border border-white/15 overflow-hidden shadow-xl">
              <div className="relative h-72 sm:h-80 bg-zinc-900 overflow-hidden">
                <iframe
                  title="Johar Wala Outfit Location Map"
                  src={STORE_INFO.googleMapsEmbedUrl}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  loading="lazy"
                  allowFullScreen
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full filter contrast-[105%]"
                />

                {/* Bottom Overlay bar */}
                <div className="absolute bottom-3 inset-x-3 z-10 flex items-center justify-between bg-black/90 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/20 text-xs shadow-lg">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-white font-bold">Shop #8, Al Noor Centre</span>
                  </div>
                  <a
                    href={STORE_INFO.googleMapsDirectionsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-black bg-white hover:bg-zinc-200 px-3 py-1 rounded-md flex items-center gap-1 font-bold text-[11px] transition-colors"
                  >
                    <Navigation className="w-3 h-3 fill-black" />
                    <span>Navigate</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Quick WhatsApp Inquiry Form */}
            <div className="p-6 bg-zinc-950 rounded-2xl border border-white/15">
              <div className="mb-4">
                <h4 className="text-base font-bold text-white uppercase font-heading tracking-wide">
                  Quick Inquiry with hiituuu
                </h4>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Send a direct question regarding stock, custom sizes, or visit timings.
                </p>
              </div>

              <form onSubmit={handleSendMessage} className="space-y-3">
                <div>
                  <input
                    type="text"
                    placeholder="Your Name (optional)"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-white/30"
                  />
                </div>
                <div>
                  <textarea
                    rows={2}
                    placeholder="E.g., Hey hiituuu, do you have size L available in the obsidian boxy tee today?"
                    value={formQuery}
                    onChange={(e) => setFormQuery(e.target.value)}
                    className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-white/30 resize-none"
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-lg bg-white hover:bg-zinc-200 text-black font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-98"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send via WhatsApp (+91 63537 90321)</span>
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
