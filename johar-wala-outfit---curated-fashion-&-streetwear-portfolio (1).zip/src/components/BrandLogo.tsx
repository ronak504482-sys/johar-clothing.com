import React, { useState } from 'react';

interface BrandLogoProps {
  variant?: 'header' | 'hero' | 'footer' | 'badge';
  className?: string;
  showSubtitle?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  variant = 'header',
  className = '',
  showSubtitle = true
}) => {
  const [imageError, setImageError] = useState(false);

  // High-fidelity vector SVG representation of the emblem
  // Matching the uploaded black & white artwork:
  // Central celestial tote bag with planetary orbital ring, sparkle star clusters,
  // stylized speedy typography "JOHAR_WALAOUTFIT" and handwritten script "Outfit by hiituuu"
  const renderVectorEmblem = (size: 'sm' | 'md' | 'lg') => {
    const isSm = size === 'sm';
    const isLg = size === 'lg';

    return (
      <div className={`relative flex flex-col items-center justify-center ${isSm ? 'w-10 h-10' : isLg ? 'w-28 h-28' : 'w-16 h-16'} bg-black rounded-lg border border-white/10 shrink-0 overflow-hidden`}>
        <svg
          viewBox="0 0 140 140"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full p-1"
          aria-label="Johar Wala Outfit Official Logo"
        >
          {/* Sparkle Stars */}
          <path
            d="M 32 45 Q 32 38 40 38 Q 32 38 32 31 Q 32 38 24 38 Q 32 38 32 45 Z"
            fill="white"
          />
          <path
            d="M 108 42 Q 108 37 114 37 Q 108 37 108 32 Q 108 37 102 37 Q 108 37 108 42 Z"
            fill="white"
          />
          <path
            d="M 70 88 Q 70 84 74 84 Q 70 84 70 80 Q 70 84 66 84 Q 70 84 70 88 Z"
            fill="white"
          />

          {/* Shopping Tote Bag Contour */}
          <rect
            x="56"
            y="44"
            width="28"
            height="30"
            rx="4"
            stroke="white"
            strokeWidth="3.5"
            fill="none"
          />
          {/* Bag Handle */}
          <path
            d="M 63 44 C 63 35, 77 35, 77 44"
            stroke="white"
            strokeWidth="3.5"
            strokeLinecap="round"
            fill="none"
          />
          {/* Subtle interior emblem tag */}
          <circle cx="70" cy="54" r="2.2" fill="white" />

          {/* Orbital Ring wrapping the shopping bag */}
          <ellipse
            cx="70"
            cy="60"
            rx="45"
            ry="13"
            transform="rotate(-15 70 60)"
            stroke="white"
            strokeWidth="3.2"
            fill="none"
          />
        </svg>
      </div>
    );
  };

  if (variant === 'badge') {
    return (
      <div className={`inline-flex flex-col items-center bg-black/90 p-4 rounded-xl border border-white/15 backdrop-blur-md shadow-2xl ${className}`}>
        {!imageError ? (
          <img
            src="/johar-logo.jpg"
            alt="Johar Wala Outfit Official Logo"
            className="w-48 sm:w-56 h-auto object-contain rounded-lg"
            referrerPolicy="no-referrer"
            onError={() => setImageError(true)}
          />
        ) : (
          <div className="flex flex-col items-center text-center p-2">
            {renderVectorEmblem('lg')}
            <span className="mt-3 text-lg font-extrabold tracking-wider text-white uppercase font-heading">
              JOHAR_WALAOUTFIT
            </span>
            <span className="text-xs italic text-zinc-300 font-serif tracking-widest mt-0.5">
              — Outfit by hiituuu ⌂ —
            </span>
          </div>
        )}
      </div>
    );
  }

  if (variant === 'hero') {
    return (
      <div className={`flex flex-col items-center text-center ${className}`}>
        <div className="relative group mb-3">
          <div className="absolute -inset-1 bg-gradient-to-r from-white/20 via-zinc-400/10 to-white/20 rounded-2xl blur-sm opacity-50 group-hover:opacity-80 transition duration-500" />
          <div className="relative p-2 bg-black rounded-xl border border-white/20 flex items-center justify-center">
            {!imageError ? (
              <img
                src="/johar-logo.jpg"
                alt="Johar Wala Outfit Logo"
                className="w-40 sm:w-52 h-auto object-contain rounded-lg"
                referrerPolicy="no-referrer"
                onError={() => setImageError(true)}
              />
            ) : (
              <div className="flex flex-col items-center px-4 py-2">
                {renderVectorEmblem('md')}
                <span className="text-xl sm:text-2xl font-extrabold tracking-widest text-white uppercase font-heading mt-2">
                  JOHAR_WALAOUTFIT
                </span>
                <span className="text-xs italic tracking-widest text-zinc-300 font-serif">
                  — Outfit by hiituuu ⌂ —
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Header and Default Variant
  return (
    <div className={`flex items-center gap-3.5 ${className}`}>
      {/* Visual Logo Mark */}
      <div className="relative shrink-0">
        {!imageError ? (
          <div className="h-11 sm:h-12 w-auto max-w-[130px] rounded-lg overflow-hidden bg-black border border-white/20 flex items-center justify-center p-1 group-hover:border-white/40 transition-colors">
            <img
              src="/johar-logo.jpg"
              alt="Johar Wala Outfit Logo"
              className="h-full w-auto object-contain"
              referrerPolicy="no-referrer"
              onError={() => setImageError(true)}
            />
          </div>
        ) : (
          renderVectorEmblem('sm')
        )}
      </div>

      {/* Website Name highlighted in bold letters */}
      <div className="flex flex-col leading-none">
        <span className="text-base sm:text-lg font-black tracking-tight text-white uppercase font-heading">
          JOHAR WALA OUTFIT
        </span>
        {showSubtitle && (
          <span className="text-[11px] tracking-widest text-zinc-400 font-medium uppercase mt-0.5">
            Outfit by hiituuu
          </span>
        )}
      </div>
    </div>
  );
};
