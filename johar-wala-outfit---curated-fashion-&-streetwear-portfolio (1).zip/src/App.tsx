/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Navbar } from './components/Navbar';
import { TopStoreMapSection } from './components/TopStoreMapSection';
import { Hero } from './components/Hero';
import { MarqueeBanner } from './components/MarqueeBanner';
import { TimingSection } from './components/TimingSection';
import { AboutSection } from './components/AboutSection';
import { ClientFeedback } from './components/ClientFeedback';
import { LocationSection } from './components/LocationSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';

export default function App() {
  return (
    <div className="min-h-screen bg-[#08080a] text-[#f4f4f6] font-sans antialiased selection:bg-white selection:text-black">
      {/* Top Bar Navigation */}
      <Navbar />

      {/* Main Content Area */}
      <main>
        {/* Full Working Map & Store Location Command Center on Top */}
        <TopStoreMapSection />

        {/* Hero Section with Directional Animations & In-Store Garment Display */}
        <Hero />

        {/* Dynamic Infinite Marquee Ribbon */}
        <MarqueeBanner />

        {/* Dedicated Eye-Catching Store & Website Timing Column (9:00 AM to 8:00 PM) */}
        <TimingSection />

        {/* Brand Story, Philosophy & hiituuu's Tailoring Atelier */}
        <AboutSection />

        {/* Client Perspectives from Bharuch */}
        <ClientFeedback />

        {/* Location, Store Directions, Contact & WhatsApp Portal */}
        <LocationSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating WhatsApp / Quick Contact Widget */}
      <FloatingWhatsApp />
    </div>
  );
}
