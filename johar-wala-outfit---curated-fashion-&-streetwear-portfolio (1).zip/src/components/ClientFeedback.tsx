import React from 'react';
import { motion } from 'motion/react';
import { Quote, Sparkles, MapPin } from 'lucide-react';
import { CLIENT_TESTIMONIALS } from '../data/storeData';

export const ClientFeedback: React.FC = () => {
  return (
    <section className="py-16 lg:py-24 bg-[#08080a] border-b border-white/10 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="text-center max-w-2xl mx-auto mb-12"
        >
          <span className="text-xs font-mono uppercase tracking-widest text-zinc-500">
            LOCAL WORD OF MOUTH · BHARUCH
          </span>
          <h3 className="text-2xl sm:text-3xl font-black uppercase text-white font-heading tracking-tight mt-1">
            CLIENT PERSPECTIVES
          </h3>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {CLIENT_TESTIMONIALS.map((t, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="p-6 bg-zinc-950 rounded-xl border border-white/10 flex flex-col justify-between"
            >
              <div>
                <Quote className="w-5 h-5 text-zinc-600 mb-3" />
                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed italic mb-4 font-light">
                  "{t.quote}"
                </p>
              </div>

              <div className="pt-4 border-t border-white/5 flex items-center justify-between text-xs">
                <div>
                  <h4 className="font-bold text-white">{t.author}</h4>
                  <span className="text-zinc-500 text-[11px] flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-zinc-500" />
                    <span>{t.location}</span>
                  </span>
                </div>
                <span className="text-[11px] text-zinc-400 font-mono bg-zinc-900 px-2 py-0.5 rounded border border-white/5">
                  {t.item}
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
