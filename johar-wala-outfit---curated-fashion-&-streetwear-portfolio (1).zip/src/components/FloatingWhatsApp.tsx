import React, { useState, useEffect } from 'react';
import { MessageCircle, Phone, X } from 'lucide-react';
import { STORE_INFO } from '../data/storeData';

export const FloatingWhatsApp: React.FC = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setVisible(true);
      } else {
        setVisible(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!visible) return null;

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2.5 animate-in fade-in slide-in-from-bottom duration-300">
      {/* Quick Call */}
      <a
        href={`tel:${STORE_INFO.phone}`}
        className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-900/90 text-white text-xs font-semibold border border-white/20 shadow-xl hover:bg-zinc-800 transition-all"
        title="Call Shop 8"
      >
        <Phone className="w-3.5 h-3.5 text-zinc-300" />
        <span className="hidden sm:inline">Call Store</span>
      </a>

      {/* Main WhatsApp CTA */}
      <a
        href={STORE_INFO.whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="group flex items-center gap-2.5 pl-3.5 pr-4 py-2.5 rounded-full bg-white hover:bg-zinc-100 text-black shadow-2xl transition-all duration-200 hover:scale-105 active:scale-95"
        aria-label="Direct WhatsApp Chat with hiituuu"
      >
        <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0 shadow-sm">
          <MessageCircle className="w-3.5 h-3.5 fill-white" />
        </div>
        <div className="flex flex-col text-left leading-none">
          <span className="text-[10px] uppercase font-mono text-zinc-600 font-semibold">
            Johar Wala Outfit
          </span>
          <span className="text-xs font-bold text-black">
            Chat with hiituuu
          </span>
        </div>
      </a>
    </div>
  );
};
