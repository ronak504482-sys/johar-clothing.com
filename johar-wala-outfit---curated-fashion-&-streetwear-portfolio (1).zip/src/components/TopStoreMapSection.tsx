import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  MapPin,
  Navigation,
  Phone,
  MessageCircle,
  Instagram,
  Copy,
  Check,
  ExternalLink,
  Clock,
  Layers,
  Sparkles,
  Compass,
  Car,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { STORE_INFO } from '../data/storeData';

export const TopStoreMapSection: React.FC = () => {
  const [mapType, setMapType] = useState<'roadmap' | 'satellite'>('satellite');
  const [copied, setCopied] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isOpenNow, setIsOpenNow] = useState(true);

  // Check store opening hours (9:00 AM to 8:00 PM IST)
  useEffect(() => {
    const checkOpenStatus = () => {
      // Calculate approximate IST or current local time
      const now = new Date();
      const hours = now.getHours();
      setIsOpenNow(hours >= STORE_INFO.openHour && hours < STORE_INFO.closeHour);
    };

    checkOpenStatus();
    const interval = setInterval(checkOpenStatus, 60000);
    return () => clearInterval(interval);
  }, []);

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(STORE_INFO.address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const mapEmbedUrl =
    mapType === 'satellite'
      ? STORE_INFO.googleMapsSatelliteEmbedUrl
      : STORE_INFO.googleMapsRoadmapEmbedUrl;

  return (
    <section
      id="store-location"
      className="relative bg-[#09090c] border-b border-white/10 pt-6 pb-12 sm:pb-16 overflow-hidden"
    >
      {/* Ambient background glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-emerald-500/5 blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Highlight Banner: Store Location + Live Open Badge */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-5 border-b border-white/10">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-zinc-400 mb-1.5">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                {isOpenNow ? 'STORE OPEN NOW' : 'OPENS AT 9:00 AM'}
              </span>
              <span className="text-zinc-600">·</span>
              <span className="text-zinc-300 font-bold tracking-wider uppercase">
                {STORE_INFO.hours} (OPEN ALL 7 DAYS)
              </span>
            </div>

            <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black uppercase text-white font-heading tracking-tight">
              STORE LOCATION & LIVE MAP
            </h1>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1 max-w-3xl">
              Visit <strong className="text-white">JOHAR WALA OUTFIT</strong> (Outfit by hiituuu) at{' '}
              <span className="text-zinc-200 font-medium">Shop Number 8, Al Noor Shopping Centre, Nandelav, Bharuch, Gujarat</span>.
            </p>
          </div>

          {/* Quick Direct Actions on the Header */}
          <div className="flex flex-wrap items-center gap-2 self-start md:self-center shrink-0">
            <a
              href={STORE_INFO.googleMapsDirectionsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-black font-bold text-xs shadow-md hover:bg-zinc-200 transition-all active:scale-95"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>Get Directions</span>
            </a>

            <a
              href={STORE_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500/20 via-rose-500/20 to-purple-600/20 border border-rose-500/40 text-white font-semibold text-xs hover:border-rose-400 transition-all"
              title="Official Instagram Page"
            >
              <Instagram className="w-3.5 h-3.5 text-pink-400" />
              <span>{STORE_INFO.instagramHandle}</span>
              <ExternalLink className="w-3 h-3 text-zinc-400" />
            </a>

            <button
              onClick={handleCopyAddress}
              className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white border border-white/10 text-xs font-mono transition-colors"
              title="Copy Address"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Address'}</span>
            </button>
          </div>
        </div>

        {/* The Full Working Map Section Container */}
        <div className={`relative transition-all duration-300 ${isFullscreen ? 'fixed inset-4 z-50 bg-black/95 p-4 rounded-2xl shadow-2xl flex flex-col' : ''}`}>
          {/* Map Frame with Interactive Controls Bar */}
          <div className="relative rounded-2xl overflow-hidden border border-white/20 bg-zinc-950 shadow-2xl">
            {/* Top Interactive Controls Toolbar */}
            <div className="bg-zinc-900/95 backdrop-blur-md px-4 py-3 border-b border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
              {/* Left Pin Label */}
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-red-600 text-white flex items-center justify-center font-bold shadow-md">
                  <MapPin className="w-4 h-4 fill-white text-white" />
                </div>
                <div>
                  <div className="font-bold text-white uppercase tracking-tight flex items-center gap-1.5">
                    <span>Shop 8 · Al Noor Shopping Centre</span>
                    <span className="text-[10px] font-mono text-cyan-300 bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-500/40 flex items-center gap-1">
                      <span>🛰️ Satellite View</span>
                    </span>
                  </div>
                  <span className="text-[11px] text-zinc-400 font-mono">
                    Chavaj Rd, Nandelav, Bharuch, Gujarat 392015
                  </span>
                </div>
              </div>

              {/* Right View Mode Toggles */}
              <div className="flex items-center gap-2">
                {/* Roadmap / Satellite switcher */}
                <div className="flex items-center p-0.5 bg-black/60 rounded-lg border border-white/10">
                  <button
                    onClick={() => setMapType('roadmap')}
                    className={`px-3 py-1 rounded-md text-[11px] font-medium transition-all ${
                      mapType === 'roadmap'
                        ? 'bg-white text-black font-bold shadow-sm'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    Street Map
                  </button>
                  <button
                    onClick={() => setMapType('satellite')}
                    className={`px-3 py-1 rounded-md text-[11px] font-medium transition-all ${
                      mapType === 'satellite'
                        ? 'bg-white text-black font-bold shadow-sm'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    Satellite View
                  </button>
                </div>

                {/* Open in external Google Maps */}
                <a
                  href={STORE_INFO.googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white border border-white/10 transition-colors flex items-center gap-1 text-[11px]"
                  title="Open full interactive map on Google Maps"
                >
                  <span>Open Full Map</span>
                  <ExternalLink className="w-3 h-3 text-zinc-400" />
                </a>

                {/* Fullscreen Expand/Collapse */}
                <button
                  onClick={() => setIsFullscreen(!isFullscreen)}
                  className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white border border-white/10 transition-colors"
                  title={isFullscreen ? 'Exit Fullscreen' : 'View Fullscreen Map'}
                  aria-label="Toggle Fullscreen"
                >
                  {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* The Working Live Google Maps Embed */}
            <div className={`w-full relative bg-zinc-900 ${isFullscreen ? 'flex-1 min-h-[500px]' : 'h-[360px] sm:h-[460px] lg:h-[520px]'}`}>
              <iframe
                title="Johar Wala Outfit Store Location Map"
                src={mapEmbedUrl}
                width="100%"
                height="100%"
                style={{ border: 0 }}
                loading="eager"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full filter contrast-[105%] saturate-[110%]"
              />

              {/* Floating Quick Navigation Overlay Pill */}
              <div className="absolute bottom-4 left-4 right-4 sm:right-auto sm:max-w-md z-10 pointer-events-auto">
                <div className="bg-black/90 backdrop-blur-md p-4 rounded-xl border border-white/20 shadow-2xl flex flex-col gap-2.5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        <span className="text-[11px] font-mono uppercase text-emerald-400 font-bold">
                          Johar Wala Outfit · Shop #8
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-white mt-0.5">
                        Al Noor Shopping Centre, Nandelav
                      </h4>
                      <p className="text-xs text-zinc-300 mt-0.5 leading-snug">
                        Bharuch, Gujarat · Outfit by hiituuu
                      </p>
                    </div>

                    <a
                      href={STORE_INFO.googleMapsDirectionsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-2 rounded-lg bg-emerald-400 hover:bg-emerald-300 text-black font-extrabold text-xs flex items-center gap-1.5 shadow-md shrink-0 transition-transform active:scale-95"
                    >
                      <Navigation className="w-3.5 h-3.5 fill-black" />
                      <span>Navigate</span>
                    </a>
                  </div>

                  <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-zinc-400">
                    <span>🕒 Timings: 9:00 AM – 8:00 PM</span>
                    <a href={`tel:${STORE_INFO.phone}`} className="text-white hover:underline font-mono">
                      📞 {STORE_INFO.displayPhone}
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Exit Fullscreen Button */}
          {isFullscreen && (
            <div className="mt-3 flex justify-end">
              <button
                onClick={() => setIsFullscreen(false)}
                className="px-4 py-2 bg-white text-black font-bold text-xs rounded-xl shadow-lg"
              >
                Close Fullscreen Map
              </button>
            </div>
          )}
        </div>

        {/* 4 Dedicated Shop Information Pillars (Location, Instagram, Timings, Direct Contact) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          {/* Card 1: Exact Address & Directions */}
          <div className="p-5 bg-zinc-950 rounded-2xl border border-white/15 flex flex-col justify-between hover:border-white/30 transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono uppercase tracking-widest text-zinc-400">
                  Shop Address
                </span>
                <MapPin className="w-4 h-4 text-emerald-400" />
              </div>
              <h3 className="text-base font-bold text-white">
                Shop No. 8, Al Noor Shopping Centre
              </h3>
              <p className="text-xs text-zinc-300 mt-1 font-mono">
                Chavaj Rd, Nandelav, Bharuch, Gujarat 392015
              </p>
              <div className="mt-3 text-[11px] text-zinc-400 space-y-1">
                <p>• Complex: Al Noor Shopping Centre, Chavaj Rd</p>
                <p>• 3.2 km (~8 min) from Bharuch Railway Station</p>
              </div>
            </div>

            <div className="pt-4 mt-4 border-t border-white/10 flex items-center gap-2">
              <button
                onClick={handleCopyAddress}
                className="flex-1 py-2 px-2.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-white/10 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Full'}</span>
              </button>
              <a
                href={STORE_INFO.googleMapsDirectionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2 px-3 rounded-lg bg-white hover:bg-zinc-200 text-black text-xs font-bold flex items-center gap-1 transition-colors"
                title="Directions"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Go</span>
              </a>
            </div>
          </div>

          {/* Card 2: Official Instagram Page Highlight */}
          <div className="p-5 bg-gradient-to-b from-zinc-950 to-zinc-900 rounded-2xl border border-rose-500/30 flex flex-col justify-between hover:border-rose-400/60 transition-all relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-rose-500/10 to-amber-500/10 rounded-full blur-xl pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono uppercase tracking-widest text-rose-300 font-semibold">
                  Official Instagram
                </span>
                <Instagram className="w-4 h-4 text-pink-400" />
              </div>
              <h3 className="text-base font-bold text-white flex items-center gap-1.5">
                <span>{STORE_INFO.instagramHandle}</span>
                <span className="w-2 h-2 rounded-full bg-rose-500" />
              </h3>
              <p className="text-xs text-zinc-300 mt-1">
                Outfit by hiituuu · Bharuch
              </p>
              <p className="text-[11px] text-zinc-400 mt-2 leading-relaxed">
                Watch viral Bharuch reels, daily fit drops, and preview in-store arrivals before visiting.
              </p>
            </div>

            <div className="pt-4 mt-4 border-t border-white/10 flex flex-col gap-2">
              <a
                href={STORE_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-3 rounded-lg bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:opacity-95 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-all active:scale-98"
              >
                <Instagram className="w-3.5 h-3.5 text-white" />
                <span>Follow @johar_walaoutfit</span>
                <ExternalLink className="w-3 h-3 text-white/80" />
              </a>

              <a
                href={STORE_INFO.instagramReelUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] text-zinc-400 hover:text-rose-300 text-center font-mono transition-colors"
              >
                Watch Latest In-Store Reel →
              </a>
            </div>
          </div>

          {/* Card 3: Store Operating Hours */}
          <div className="p-5 bg-zinc-950 rounded-2xl border border-white/15 flex flex-col justify-between hover:border-white/30 transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono uppercase tracking-widest text-zinc-400">
                  Store Operating Hours
                </span>
                <Clock className="w-4 h-4 text-emerald-400" />
              </div>
              <h3 className="text-xl font-extrabold text-white font-mono tracking-tight">
                9:00 AM – 8:00 PM
              </h3>
              <p className="text-xs text-emerald-400 mt-1 font-semibold">
                Open All 7 Days (Mon - Sun)
              </p>
              <div className="mt-3 text-[11px] text-zinc-400 space-y-1">
                <p>• Founder hiituuu available in-store</p>
                <p>• Bespoke fit adjustments & length hemming</p>
                <p>• Private trial room with studio lighting</p>
              </div>
            </div>

            <div className="pt-4 mt-4 border-t border-white/10">
              <a
                href="#timings"
                className="w-full py-2 px-3 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-200 hover:text-white border border-white/10 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Clock className="w-3.5 h-3.5 text-emerald-400" />
                <span>View Full Timing Matrix</span>
              </a>
            </div>
          </div>

          {/* Card 4: Direct WhatsApp & Phone Line */}
          <div className="p-5 bg-zinc-950 rounded-2xl border border-white/15 flex flex-col justify-between hover:border-white/30 transition-all">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono uppercase tracking-widest text-zinc-400">
                  Direct Inquiries & Calls
                </span>
                <Phone className="w-4 h-4 text-zinc-400" />
              </div>
              <h3 className="text-lg font-bold text-white font-mono">
                {STORE_INFO.displayPhone}
              </h3>
              <p className="text-xs text-zinc-400 mt-1">
                Direct mobile line to boutique
              </p>
              <p className="text-[11px] text-zinc-400 mt-2 leading-relaxed">
                Check size availability, book in-store fitting, or reserve a piece before dropping by Shop No. 8.
              </p>
            </div>

            <div className="pt-4 mt-4 border-t border-white/10 flex items-center gap-2">
              <a
                href={`tel:${STORE_INFO.phone}`}
                className="flex-1 py-2 px-3 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-white border border-white/10 text-xs font-semibold text-center transition-colors"
              >
                Call Store
              </a>
              <a
                href={STORE_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold text-center flex items-center justify-center gap-1 transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5 fill-black" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
