import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, MessageCircle, Phone, Check, Sparkles, MapPin, Ruler } from 'lucide-react';
import { ShowcaseItem, STORE_INFO } from '../data/storeData';

interface ItemModalProps {
  item: ShowcaseItem | null;
  onClose: () => void;
}

export const ItemModal: React.FC<ItemModalProps> = ({ item, onClose }) => {
  const [selectedSize, setSelectedSize] = useState<string>(item?.sizes[0] || 'M');

  if (!item) return null;

  const whatsappMessage = encodeURIComponent(
    `Hello hiituuu, I am inquiring about "${item.name}" (Size: ${selectedSize}) from Johar Wala Outfit showcase. Is it available at Shop No. 8, Al Noor Shopping Centre?`
  );

  const whatsappLink = `https://wa.me/${STORE_INFO.whatsappNumber}?text=${whatsappMessage}`;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        {/* Swipe Up Modal Container */}
        <motion.div
          initial={{ opacity: 0, y: 60, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 60, scale: 0.96 }}
          transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-4xl bg-zinc-950 border border-white/20 rounded-2xl overflow-hidden shadow-2xl z-10 max-h-[90vh] flex flex-col lg:flex-row"
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/70 hover:bg-black text-zinc-300 hover:text-white border border-white/10 transition-colors focus-visible:outline-none"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Left Column: Garment Atelier Blueprint & Technical Spec (Zero cloth photos) */}
          <div className="lg:w-1/2 relative bg-zinc-900 p-8 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-white/10 shrink-0 min-h-[300px] lg:min-h-full overflow-hidden">
            {/* Ambient blueprint grid pattern */}
            <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]" />

            <div className="relative z-10">
              <div className="flex items-center justify-between gap-2 mb-6">
                <span className="px-3 py-1 rounded-md bg-white/10 text-white font-mono text-xs font-bold uppercase tracking-wider border border-white/15">
                  {item.badge || 'Archive Drop'}
                </span>
                <span className="px-3 py-1 rounded-md bg-emerald-950/80 text-emerald-400 font-mono text-xs border border-emerald-500/30">
                  {item.gsm}
                </span>
              </div>

              <div className="space-y-4">
                <span className="text-[11px] font-mono uppercase tracking-widest text-zinc-500 block">
                  ATELIER SPECIFICATION SHEET
                </span>
                <h3 className="text-2xl sm:text-3xl font-black uppercase text-white font-heading tracking-tight">
                  {item.name}
                </h3>
                <div className="p-4 rounded-xl bg-black/60 border border-white/10 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-zinc-400">Fabric Composition:</span>
                    <span className="text-white font-medium text-right">{item.fabric}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">Silhouette Fit:</span>
                    <span className="text-white font-medium text-right">{item.fit}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">Colorway:</span>
                    <span className="text-white font-medium text-right">{item.color}</span>
                  </div>
                  {item.inStoreLocation && (
                    <div className="flex justify-between pt-2 border-t border-white/10">
                      <span className="text-emerald-400">In-Store Rack:</span>
                      <span className="text-emerald-300 font-mono font-medium">{item.inStoreLocation}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="relative z-10 pt-6 mt-6 border-t border-white/10 flex items-center justify-between text-xs text-zinc-400 font-mono">
              <span>JOHAR WALA OUTFIT</span>
              <span>SHOP #8 · BHARUCH</span>
            </div>
          </div>

          {/* Right Column: Garment Specs & Ordering */}
          <div className="lg:w-1/2 p-6 sm:p-8 overflow-y-auto flex flex-col justify-between">
            <div>
              {/* Category & Brand */}
              <div className="flex items-center gap-2 text-xs text-zinc-400 font-mono uppercase tracking-wider mb-1">
                <span>{item.category}</span>
                <span>·</span>
                <span className="text-white font-bold">JOHAR WALA OUTFIT</span>
              </div>

              {/* Title & Price */}
              <h2 className="text-2xl sm:text-3xl font-black text-white uppercase font-heading tracking-tight mb-2">
                {item.name}
              </h2>

              <div className="flex items-baseline gap-3 mb-4">
                <span className="text-2xl font-bold font-mono text-white tabular-nums">
                  ₹{item.price.toLocaleString('en-IN')}
                </span>
                {item.originalPrice && (
                  <span className="text-sm font-mono text-zinc-500 line-through tabular-nums">
                    ₹{item.originalPrice.toLocaleString('en-IN')}
                  </span>
                )}
                <span className="text-xs text-emerald-400 font-medium">Bespoke In-Store Fit</span>
              </div>

              {/* Description */}
              <p className="text-sm text-zinc-300 leading-relaxed mb-6">
                {item.description}
              </p>

              {/* Garment Specifications Matrix */}
              <div className="bg-zinc-900/80 rounded-xl p-4 border border-white/10 space-y-2 mb-6 text-xs">
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-zinc-400">Fabric Composition:</span>
                  <span className="text-zinc-200 font-medium text-right">{item.fabric}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-zinc-400">Fabric Density:</span>
                  <span className="text-zinc-200 font-medium font-mono">{item.gsm}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-zinc-400">Silhouette Cut:</span>
                  <span className="text-zinc-200 font-medium text-right">{item.fit}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-zinc-400">Color Tone:</span>
                  <span className="text-zinc-200 font-medium">{item.color}</span>
                </div>
              </div>

              {/* Size Selector */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-semibold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
                    <Ruler className="w-3.5 h-3.5 text-zinc-400" />
                    <span>Select Size</span>
                  </label>
                  <span className="text-[11px] text-zinc-400">Free In-Store Hemming</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {item.sizes.map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setSelectedSize(sz)}
                      className={`min-w-10 px-3 py-1.5 text-xs font-bold rounded-lg border transition-all ${
                        selectedSize === sz
                          ? 'bg-white text-black border-white shadow-md'
                          : 'bg-zinc-900 text-zinc-300 border-white/10 hover:border-white/30'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>

              {/* Key Bullet Highlights */}
              <div className="space-y-1.5 mb-8">
                <span className="text-xs font-mono uppercase tracking-wider text-zinc-400 block mb-2">
                  Construction Notes
                </span>
                {item.details.map((detail, idx) => (
                  <div key={idx} className="flex items-start gap-2 text-xs text-zinc-300">
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{detail}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Direct Actions */}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <a
                href={whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-3 px-4 text-sm font-bold text-black bg-white hover:bg-zinc-200 rounded-lg shadow-lg transition-all active:scale-98"
              >
                <MessageCircle className="w-4 h-4 fill-black" />
                <span>Inquire & Reserve on WhatsApp (Size: {selectedSize})</span>
              </a>

              <div className="flex items-center justify-between text-xs text-zinc-400 px-1">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-zinc-500" />
                  <span>Shop #8 Al Noor Shopping Centre</span>
                </span>
                <a href={`tel:${STORE_INFO.phone}`} className="hover:text-white underline">
                  Call {STORE_INFO.phone}
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
