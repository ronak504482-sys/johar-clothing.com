import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft,
  ArrowRight,
  Sparkles,
  Eye,
  MessageCircle,
  Layers,
  SlidersHorizontal,
  MapPin,
  CheckCircle2,
  ExternalLink,
  Play,
  Ruler
} from 'lucide-react';
import {
  SHOWCASE_COLLECTION,
  ShowcaseItem,
  STORE_INFO
} from '../data/storeData';
import { ItemModal } from './ItemModal';

export const ShowcaseSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'spotlight' | 'grid'>('spotlight');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState<'left' | 'right'>('right');
  const [modalItem, setModalItem] = useState<ShowcaseItem | null>(null);

  const totalItems = SHOWCASE_COLLECTION.length;
  const currentItem = SHOWCASE_COLLECTION[currentIndex];

  const handleNext = () => {
    setDirection('right');
    setCurrentIndex((prev) => (prev + 1) % totalItems);
  };

  const handlePrev = () => {
    setDirection('left');
    setCurrentIndex((prev) => (prev - 1 + totalItems) % totalItems);
  };

  // Animation variants for directional swipe transitions
  const slideVariants = {
    enter: (dir: 'left' | 'right') => ({
      x: dir === 'right' ? 80 : -80,
      opacity: 0
    }),
    center: {
      x: 0,
      opacity: 1
    },
    exit: (dir: 'left' | 'right') => ({
      x: dir === 'right' ? -80 : 80,
      opacity: 0
    })
  };

  return (
    <section id="showcase" className="py-20 lg:py-28 bg-[#09090b] relative overflow-hidden border-b border-white/10">
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-zinc-700/5 blur-[100px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header: Swipe Down Animation */}
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-white/10 gap-6"
        >
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-white/10 text-xs font-mono text-zinc-400 mb-3">
              <Sparkles className="w-3.5 h-3.5 text-zinc-400" />
              <span>SHOP NO. 8 · IN-STORE SILHOUETTES</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-black uppercase text-white font-heading tracking-tight">
              CURATED <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-zinc-200 to-zinc-400">4 SILHOUETTES</span>
            </h2>
            <p className="mt-2 text-sm sm:text-base text-zinc-400 max-w-2xl font-light">
              <strong className="text-white font-bold">JOHAR WALA OUTFIT</strong> (Outfit by hiituuu) at Shop No. 8 Al Noor Centre, Bharuch.
              Explore our current in-store silhouettes, textile compositions, and bespoke fit specifications.
            </p>
          </div>

          {/* View Mode Switcher: Spotlight & All 4 Silhouettes */}
          <div className="flex items-center gap-1.5 p-1 bg-zinc-900 border border-white/10 rounded-xl shrink-0 self-start md:self-end">
            <button
              onClick={() => setActiveTab('spotlight')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'spotlight'
                  ? 'bg-white text-black shadow-sm font-bold'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Spotlight Blueprint</span>
            </button>
            <button
              onClick={() => setActiveTab('grid')}
              className={`flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                activeTab === 'grid'
                  ? 'bg-white text-black shadow-sm font-bold'
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>All 4 Silhouettes ({totalItems})</span>
            </button>
          </div>
        </motion.div>

        {/* View Mode 1: Interactive Spotlight */}
        {activeTab === 'spotlight' && (
          <div className="relative">
            {/* Main Spotlight Card */}
            <div className="bg-zinc-950/70 border border-white/15 rounded-2xl overflow-hidden shadow-2xl">
              <AnimatePresence mode="wait" custom={direction}>
                <motion.div
                  key={currentItem.id}
                  custom={direction}
                  variants={slideVariants}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                  className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center"
                >
                  {/* Left Column: Atelier Silhouette Blueprint Card (Zero cloth photos) */}
                  <div className="lg:col-span-6 relative aspect-[3/4] sm:aspect-[4/3] lg:aspect-square bg-gradient-to-br from-zinc-900 via-zinc-950 to-black p-8 sm:p-10 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-white/10 rounded-xl overflow-hidden">
                    {/* Blueprint grid background */}
                    <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:20px_20px] pointer-events-none" />

                    {/* Top Watermark & Badges */}
                    <div className="relative z-10 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <span className="px-3 py-1 bg-white/10 backdrop-blur-md border border-white/20 rounded-md text-xs font-bold uppercase tracking-wider text-white">
                          {currentItem.badge || 'Archive Drop'}
                        </span>
                        <span className="px-3 py-1 bg-zinc-900/90 border border-white/10 rounded-md text-xs font-mono text-emerald-400 font-semibold">
                          {currentItem.gsm}
                        </span>
                      </div>

                      {currentItem.inStoreLocation && (
                        <div className="flex items-center gap-1.5 px-3 py-1 bg-black/80 border border-white/10 rounded-md text-xs font-mono text-zinc-300">
                          <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                          <span>{currentItem.inStoreLocation}</span>
                        </div>
                      )}
                    </div>

                    {/* Center Specification Emblem */}
                    <div className="relative z-10 my-auto py-6">
                      <div className="text-[11px] font-mono text-zinc-500 uppercase tracking-widest mb-1">
                        SILHOUETTE SPECIFICATION 0{currentIndex + 1}
                      </div>
                      <h3 className="text-3xl sm:text-4xl font-black uppercase text-white font-heading tracking-tight mb-4">
                        {currentItem.name}
                      </h3>

                      <div className="grid grid-cols-2 gap-3 text-xs">
                        <div className="p-3 rounded-lg bg-black/50 border border-white/10">
                          <span className="text-[10px] font-mono uppercase text-zinc-400 block mb-0.5">Fabric</span>
                          <span className="text-white font-medium line-clamp-1">{currentItem.fabric}</span>
                        </div>
                        <div className="p-3 rounded-lg bg-black/50 border border-white/10">
                          <span className="text-[10px] font-mono uppercase text-zinc-400 block mb-0.5">Silhouette Fit</span>
                          <span className="text-white font-medium line-clamp-1">{currentItem.fit}</span>
                        </div>
                        <div className="p-3 rounded-lg bg-black/50 border border-white/10">
                          <span className="text-[10px] font-mono uppercase text-zinc-400 block mb-0.5">Colorway</span>
                          <span className="text-zinc-200 line-clamp-1">{currentItem.color}</span>
                        </div>
                        <div className="p-3 rounded-lg bg-black/50 border border-white/10">
                          <span className="text-[10px] font-mono uppercase text-zinc-400 block mb-0.5">Sizes in Store</span>
                          <span className="text-emerald-400 font-mono font-medium">{currentItem.sizes.join(' · ')}</span>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Blueprint Watermark & Actions */}
                    <div className="relative z-10 pt-4 border-t border-white/10 flex items-center justify-between text-xs">
                      <div className="font-mono text-zinc-400 text-[11px]">
                        JOHAR WALA OUTFIT · SHOP 8 BHARUCH
                      </div>

                      {currentItem.reelUrl ? (
                        <a
                          href={currentItem.reelUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500/20 via-rose-500/20 to-purple-600/20 border border-rose-500/40 text-rose-300 hover:text-white text-xs font-semibold transition-colors"
                        >
                          <Play className="w-3 h-3 fill-rose-300" />
                          <span>Watch Reel</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      ) : (
                        <button
                          onClick={() => setModalItem(currentItem)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-white text-xs border border-white/10 transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Full Specs</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Right Column: Garment Story & Specs */}
                  <div className="lg:col-span-6 p-6 sm:p-10 flex flex-col justify-between">
                    <div>
                      {/* Numerator index */}
                      <div className="flex items-center justify-between mb-4">
                        <span className="font-mono text-xs text-zinc-500 uppercase tracking-widest">
                          SILHOUETTE 0{currentIndex + 1} OF 0{totalItems}
                        </span>
                        <span className="text-xs font-mono text-emerald-400 bg-emerald-950/80 border border-emerald-500/30 px-2.5 py-0.5 rounded">
                          In Stock at Shop No. 8
                        </span>
                      </div>

                      {/* Garment Title */}
                      <h3 className="text-2xl sm:text-4xl font-black uppercase text-white font-heading tracking-tight mb-2">
                        {currentItem.name}
                      </h3>

                      {/* Category & Colorway */}
                      <div className="flex flex-wrap items-center gap-2 mb-4 text-xs font-mono">
                        <span className="text-zinc-400 uppercase tracking-wider">{currentItem.category}</span>
                        <span className="text-zinc-600">/</span>
                        <span className="text-zinc-300">{currentItem.color}</span>
                      </div>

                      {/* Price Section */}
                      <div className="flex items-baseline gap-3 mb-6">
                        <span className="text-3xl sm:text-4xl font-bold font-mono text-white tabular-nums">
                          ₹{currentItem.price.toLocaleString('en-IN')}
                        </span>
                        {currentItem.originalPrice && (
                          <span className="text-sm sm:text-base font-mono text-zinc-500 line-through tabular-nums">
                            ₹{currentItem.originalPrice.toLocaleString('en-IN')}
                          </span>
                        )}
                        <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/50 border border-emerald-500/20 px-2 py-0.5 rounded">
                          Store Exclusive Price
                        </span>
                      </div>

                      {/* Curated Description */}
                      <p className="text-sm text-zinc-300 font-light leading-relaxed mb-6">
                        {currentItem.description}
                      </p>

                      {/* Silhouette & Fabric Attributes */}
                      <div className="space-y-3 mb-6">
                        <div className="text-xs font-mono uppercase tracking-widest text-zinc-400">
                          Garment Specifications
                        </div>
                        <ul className="text-xs text-zinc-300 space-y-2">
                          {currentItem.details.slice(0, 3).map((detail, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <span className="text-emerald-400 font-mono shrink-0">✦</span>
                              <span>{detail}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Action Row */}
                    <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                      <button
                        onClick={() => setModalItem(currentItem)}
                        className="flex-1 inline-flex items-center justify-center gap-2 py-3 px-5 text-xs sm:text-sm font-bold text-black bg-white hover:bg-zinc-200 rounded-lg shadow-md transition-all active:scale-98"
                      >
                        <Eye className="w-4 h-4" />
                        <span>View Fabric & Fit Specs</span>
                      </button>

                      <a
                        href={`https://wa.me/${STORE_INFO.whatsappNumber}?text=${encodeURIComponent(
                          `Hi hiituuu, I want to reserve/inquire about "${currentItem.name}" from Johar Wala Outfit.`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center justify-center gap-2 py-3 px-5 text-xs sm:text-sm font-semibold text-white bg-zinc-900 hover:bg-zinc-800 border border-white/20 rounded-lg transition-all"
                      >
                        <MessageCircle className="w-4 h-4 text-emerald-400" />
                        <span>WhatsApp Inquiry</span>
                      </a>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Carousel Controls */}
            <div className="flex items-center justify-between mt-6">
              <div className="flex items-center gap-2">
                {SHOWCASE_COLLECTION.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setDirection(idx > currentIndex ? 'right' : 'left');
                      setCurrentIndex(idx);
                    }}
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      idx === currentIndex ? 'w-8 bg-white' : 'w-2 bg-zinc-700 hover:bg-zinc-500'
                    }`}
                    aria-label={`Go to slide ${idx + 1}`}
                  />
                ))}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrev}
                  className="p-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white border border-white/10 transition-colors focus-visible:outline-none"
                  aria-label="Previous garment"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNext}
                  className="p-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white border border-white/10 transition-colors focus-visible:outline-none"
                  aria-label="Next garment"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* View Mode 2: Full Grid View (Zero Cloth Photos) */}
        {activeTab === 'grid' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
            {SHOWCASE_COLLECTION.map((item, idx) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: idx * 0.08 }}
                className="bg-zinc-950 border border-white/10 hover:border-white/25 rounded-2xl overflow-hidden group transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  {/* Top Blueprint Card Header (Zero cloth photos) */}
                  <div className="relative p-6 bg-gradient-to-br from-zinc-900 via-zinc-950 to-black border-b border-white/10 flex flex-col justify-between min-h-[170px]">
                    <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />

                    <div className="relative z-10 flex items-center justify-between">
                      <span className="text-3xl font-black font-mono text-white/20">0{idx + 1}</span>
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded text-[11px] font-mono font-bold bg-white/10 text-white border border-white/15">
                          {item.gsm}
                        </span>
                        {item.inStoreLocation && (
                          <span className="px-2.5 py-0.5 rounded text-[10px] font-mono text-emerald-400 bg-emerald-950/80 border border-emerald-500/30">
                            {item.inStoreLocation}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="relative z-10 mt-3">
                      <span className="text-[10px] font-mono uppercase tracking-widest text-zinc-400 block mb-0.5">
                        {item.category}
                      </span>
                      <h4
                        onClick={() => setModalItem(item)}
                        className="text-lg font-black text-white group-hover:text-emerald-300 cursor-pointer uppercase font-heading transition-colors"
                      >
                        {item.name}
                      </h4>
                      <p className="text-xs text-zinc-300 mt-1 line-clamp-1 font-mono">
                        {item.fabric}
                      </p>
                    </div>
                  </div>

                  {/* Card Body Specs */}
                  <div className="p-6 space-y-4">
                    <div className="flex items-baseline justify-between">
                      <div className="flex items-baseline gap-2">
                        <span className="text-2xl font-bold font-mono text-white tabular-nums">
                          ₹{item.price.toLocaleString('en-IN')}
                        </span>
                        {item.originalPrice && (
                          <span className="text-xs font-mono text-zinc-500 line-through tabular-nums">
                            ₹{item.originalPrice.toLocaleString('en-IN')}
                          </span>
                        )}
                      </div>
                      <span className="text-xs text-zinc-400 font-mono">
                        Sizes: {item.sizes.join(', ')}
                      </span>
                    </div>

                    <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">
                      {item.description}
                    </p>

                    <div className="p-3 rounded-lg bg-zinc-900/60 border border-white/5 text-[11px] space-y-1">
                      <div className="flex justify-between">
                        <span className="text-zinc-500">Fit Silhouette:</span>
                        <span className="text-zinc-300">{item.fit}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-zinc-500">Colorway:</span>
                        <span className="text-zinc-300">{item.color}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Footer Actions */}
                <div className="p-6 pt-0 flex gap-2">
                  <button
                    onClick={() => setModalItem(item)}
                    className="flex-1 py-2.5 px-3 text-xs font-semibold text-zinc-200 hover:text-white bg-zinc-900 hover:bg-zinc-800 border border-white/10 rounded-lg transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Specifications</span>
                  </button>

                  <a
                    href={`https://wa.me/${STORE_INFO.whatsappNumber}?text=${encodeURIComponent(
                      `Hi hiituuu, I would like to inquire about "${item.name}" from Johar Wala Outfit.`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 rounded-lg bg-emerald-950/80 hover:bg-emerald-900/90 text-emerald-400 border border-emerald-500/30 transition-colors flex items-center justify-center"
                    title="Inquire on WhatsApp"
                  >
                    <MessageCircle className="w-4 h-4 fill-emerald-400" />
                  </a>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Specifications Modal (Zero cloth photos) */}
      <ItemModal item={modalItem} onClose={() => setModalItem(null)} />
    </section>
  );
};
