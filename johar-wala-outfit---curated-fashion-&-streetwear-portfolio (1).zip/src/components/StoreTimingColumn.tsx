import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Clock, CheckCircle2, Sparkles, AlertCircle, Calendar, ArrowRight, ShieldCheck } from 'lucide-react';
import { STORE_INFO } from '../data/storeData';

interface StoreTimingColumnProps {
  variant?: 'featured' | 'compact' | 'hero-card';
  className?: string;
}

export const StoreTimingColumn: React.FC<StoreTimingColumnProps> = ({
  variant = 'featured',
  className = ''
}) => {
  const [isOpenNow, setIsOpenNow] = useState(false);
  const [currentTimeStr, setCurrentTimeStr] = useState('');
  const [timeUntilClose, setTimeUntilClose] = useState('');

  useEffect(() => {
    const checkOpenStatus = () => {
      // Calculate based on Indian Standard Time (UTC+5:30) or local browser time
      const now = new Date();
      // Get current hours and minutes
      const hours = now.getHours();
      const minutes = now.getMinutes();

      // Format current time display
      const formattedTime = now.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
      setCurrentTimeStr(formattedTime);

      // Open from 9:00 AM (9) to 8:00 PM (20)
      const open = hours >= 9 && hours < 20;
      setIsOpenNow(open);

      if (open) {
        const remainingHours = 19 - hours;
        const remainingMins = 60 - minutes;
        if (remainingHours === 0) {
          setTimeUntilClose(`Closes in ${remainingMins}m`);
        } else {
          setTimeUntilClose(`Open today · Closes at 8:00 PM (${remainingHours}h ${remainingMins}m left)`);
        }
      } else {
        if (hours < 9) {
          const waitHours = 8 - hours;
          const waitMins = 60 - minutes;
          setTimeUntilClose(`Opens today at 9:00 AM (in ${waitHours}h ${waitMins}m)`);
        } else {
          setTimeUntilClose(`Closed for tonight · Reopens tomorrow at 9:00 AM`);
        }
      }
    };

    checkOpenStatus();
    const interval = setInterval(checkOpenStatus, 30000);
    return () => clearInterval(interval);
  }, []);

  const scheduleDays = [
    { day: 'Monday', hours: '9:00 AM – 8:00 PM', status: 'Full Day' },
    { day: 'Tuesday', hours: '9:00 AM – 8:00 PM', status: 'Full Day' },
    { day: 'Wednesday', hours: '9:00 AM – 8:00 PM', status: 'Full Day' },
    { day: 'Thursday', hours: '9:00 AM – 8:00 PM', status: 'Full Day' },
    { day: 'Friday', hours: '9:00 AM – 8:00 PM', status: 'Jumma Special Slots' },
    { day: 'Saturday', hours: '9:00 AM – 8:00 PM', status: 'Weekend Drop' },
    { day: 'Sunday', hours: '9:00 AM – 8:00 PM', status: 'Weekend Drop' },
  ];

  if (variant === 'hero-card') {
    return (
      <div className={`relative overflow-hidden rounded-2xl bg-zinc-950/95 border border-white/20 p-5 shadow-2xl backdrop-blur-xl ${className}`}>
        {/* Glow ambient accent */}
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-white/5 border border-white/10 text-white">
              <Clock className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <span className="text-[10px] font-mono uppercase tracking-widest text-zinc-400 block leading-tight">
                Store Schedule
              </span>
              <span className="text-xs font-bold text-white uppercase tracking-tight font-heading">
                Operational Timings
              </span>
            </div>
          </div>

          {/* Live Open / Closed Indicator Pill */}
          <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold tracking-wide border ${
            isOpenNow 
              ? 'bg-emerald-950/90 text-emerald-300 border-emerald-500/40 shadow-[0_0_12px_rgba(16,185,129,0.2)]'
              : 'bg-zinc-900 text-amber-300 border-amber-500/30'
          }`}>
            <span className={`w-2 h-2 rounded-full ${isOpenNow ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
            <span>{isOpenNow ? 'STORE OPEN NOW' : 'OPENS AT 9:00 AM'}</span>
          </div>
        </div>

        {/* Big Eye-Catching Timing Typography */}
        <div className="my-3 py-3 px-3.5 bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-zinc-900/60 rounded-xl border border-white/10 flex items-baseline justify-between">
          <div>
            <div className="text-2xl sm:text-3xl font-black font-heading text-white tracking-tight leading-none">
              9:00 AM <span className="text-zinc-500 font-light text-xl">TO</span> 8:00 PM
            </div>
            <div className="text-[11px] text-zinc-400 font-medium mt-1 flex items-center gap-1">
              <Calendar className="w-3 h-3 text-zinc-500" />
              <span>All 7 Days Open · Mon to Sun</span>
            </div>
          </div>
        </div>

        {/* Dynamic status readout */}
        <p className="text-[11px] text-zinc-300 font-mono flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-zinc-500" />
          <span>{timeUntilClose}</span>
        </p>
      </div>
    );
  }

  // Full Featured Column
  return (
    <div className={`relative flex flex-col justify-between rounded-2xl bg-zinc-950 border border-white/15 p-6 sm:p-7 shadow-2xl overflow-hidden ${className}`}>
      {/* Decorative top accent line */}
      <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-emerald-500/80 via-white/50 to-emerald-500/80" />
      
      {/* Background ambient lighting */}
      <div className="absolute -top-12 -right-12 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      <div>
        {/* Header with Live Status Tag */}
        <div className="flex items-center justify-between gap-4 mb-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-white/10 text-xs font-mono text-zinc-300">
            <Clock className="w-3.5 h-3.5 text-emerald-400" />
            <span className="uppercase tracking-wider">OFFICIAL BOUTIQUE HOURS</span>
          </div>

          {/* Eye-catching Pulsing Live Pill */}
          <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold tracking-wide border transition-all ${
            isOpenNow 
              ? 'bg-emerald-950 text-emerald-300 border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
              : 'bg-zinc-900 text-amber-300 border-amber-500/30'
          }`}>
            <span className={`w-2.5 h-2.5 rounded-full ${isOpenNow ? 'bg-emerald-400 animate-ping' : 'bg-amber-400'}`} />
            <span>{isOpenNow ? 'OPEN RIGHT NOW' : 'OPENS AT 9 AM'}</span>
          </div>
        </div>

        {/* Large Prominent Eye-Catching Display */}
        <div className="p-5 sm:p-6 rounded-xl bg-gradient-to-br from-zinc-900/90 via-zinc-900/60 to-black border border-white/15 mb-6 text-center sm:text-left relative overflow-hidden group">
          <div className="absolute -right-4 -bottom-4 text-zinc-800/20 pointer-events-none">
            <Clock className="w-32 h-32 stroke-[1]" />
          </div>

          <span className="text-xs font-mono uppercase tracking-widest text-zinc-400 block mb-1">
            Store & Website Timing
          </span>
          
          <div className="text-3xl sm:text-4xl lg:text-5xl font-black text-white font-heading tracking-tight mb-2">
            9:00 AM <span className="text-zinc-500 font-light text-2xl sm:text-3xl">TO</span> 8:00 PM
          </div>

          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-zinc-300">
            <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Open All 7 Days a Week</span>
            </span>
            <span className="text-zinc-600 hidden sm:inline">•</span>
            <span className="text-zinc-400">Shop No. 8, Al Noor Shopping Centre</span>
          </div>

          <div className="mt-4 pt-3 border-t border-white/10 text-xs font-mono text-zinc-400 flex items-center justify-between">
            <span className="text-zinc-300">{timeUntilClose}</span>
            <span className="text-[11px] text-zinc-500">Live Clock</span>
          </div>
        </div>

        {/* Eye Catching 7-Day Day Breakdown List */}
        <div className="space-y-2 mb-6">
          <div className="text-xs font-mono uppercase tracking-wider text-zinc-400 px-1 mb-2 flex items-center justify-between">
            <span>Weekly Schedule Matrix</span>
            <span className="text-emerald-400 font-sans font-medium text-[11px]">Consistent Daily Timing</span>
          </div>

          <div className="divide-y divide-white/5 rounded-xl bg-zinc-900/70 border border-white/10 overflow-hidden text-xs">
            {scheduleDays.map((item, idx) => {
              const todayIndex = (new Date().getDay() + 6) % 7; // Monday = 0
              const isToday = idx === todayIndex;
              return (
                <div
                  key={item.day}
                  className={`flex items-center justify-between px-3.5 py-2.5 transition-colors ${
                    isToday ? 'bg-white/10 font-semibold text-white' : 'text-zinc-300 hover:bg-white/5'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`w-1.5 h-1.5 rounded-full ${isToday ? 'bg-emerald-400' : 'bg-zinc-600'}`} />
                    <span className={isToday ? 'text-white' : 'text-zinc-300'}>{item.day}</span>
                    {isToday && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 uppercase font-mono tracking-wider ml-1">
                        Today
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-zinc-200">9:00 AM – 8:00 PM</span>
                    <span className="text-[10px] text-zinc-500 font-mono hidden sm:inline">({item.status})</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Helpful Visiting Notes */}
        <div className="p-3.5 rounded-xl bg-zinc-900/40 border border-white/5 text-xs text-zinc-400 space-y-1">
          <p className="flex items-start gap-1.5 text-zinc-300">
            <Sparkles className="w-3.5 h-3.5 text-zinc-400 shrink-0 mt-0.5" />
            <span><strong>Custom Sizing & Tailoring:</strong> Walk in between 9 AM and 8 PM for on-the-spot adjustments by hiituuu.</span>
          </p>
          <p className="text-[11px] text-zinc-500 pl-5">
            Evening fitting slots available by direct WhatsApp confirmation.
          </p>
        </div>
      </div>

      {/* Direct Contact Hook */}
      <div className="pt-6 mt-6 border-t border-white/10 flex items-center justify-between gap-3">
        <a
          href={`tel:${STORE_INFO.phone}`}
          className="flex-1 py-2.5 px-3 text-center text-xs font-semibold bg-zinc-900 hover:bg-zinc-800 text-white rounded-lg border border-white/10 transition-colors"
        >
          Call Store (9 AM - 8 PM)
        </a>
        <a
          href={STORE_INFO.whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 py-2.5 px-3 text-center text-xs font-bold bg-white hover:bg-zinc-200 text-black rounded-lg transition-colors flex items-center justify-center gap-1.5"
        >
          <span>Confirm Visit</span>
          <ArrowRight className="w-3 h-3" />
        </a>
      </div>
    </div>
  );
};
