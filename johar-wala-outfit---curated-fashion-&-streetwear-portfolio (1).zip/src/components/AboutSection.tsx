import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, MapPin, Instagram, ShieldCheck, Scissors, Layers, Phone } from 'lucide-react';
import { STORE_INFO, BRAND_VALUES } from '../data/storeData';
import { BrandLogo } from './BrandLogo';

export const AboutSection: React.FC = () => {
  return (
    <section id="story" className="py-20 lg:py-28 bg-[#08080a] relative overflow-hidden border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header: Swipe Down Animation */}
        <motion.div
          initial={{ opacity: 0, y: -25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900 border border-white/10 text-xs font-mono text-zinc-400 mb-3">
            <span>THE ATELIER PHILOSOPHY</span>
            <span>·</span>
            <span>Outfit by hiituuu</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black uppercase text-white font-heading tracking-tight">
            ABOUT <strong className="text-white">JOHAR WALA OUTFIT</strong>
          </h2>
          <p className="mt-3 text-base text-zinc-400 font-light">
            Founded in Nandelav, Bharuch, we set out to redefine local menswear by merging contemporary street culture with artisanal tailoring.
          </p>
        </motion.div>

        {/* 2-Column Split: Left (Left-to-Right) and Right (Right-to-Left) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center mb-16">
          {/* Left Column: Left-to-Right Story narrative */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 space-y-6"
          >
            <div className="p-6 sm:p-8 bg-zinc-950 rounded-2xl border border-white/10 shadow-xl relative">
              <h3 className="text-2xl font-bold text-white mb-4 font-heading">
                Why We Keep Our Showcase Tightly Curated
              </h3>
              <p className="text-sm sm:text-base text-zinc-300 leading-relaxed font-light mb-4">
                Walk into traditional clothing stores, and you are inundated with endless racks of generic mass production.
                At <strong className="text-white font-bold">Johar wala outfit</strong>, hiituuu took a conscious stand:
                <em className="text-white font-normal italic"> we show less because each silhouette represents weeks of pattern drafting, fabric sourcing, and fit calibration</em>.
              </p>
              <p className="text-sm sm:text-base text-zinc-300 leading-relaxed font-light">
                Our capsule drops feature only 4 to 5 master silhouettes. When you step into our studio at{' '}
                <strong className="text-zinc-200">Shop No. 8, AL NOOR SHOPPING CENTRE in Nandelav</strong>, you experience personalized styling advice, tactile fabric testing, and customized hem adjustments.
              </p>
            </div>

            {/* Brand Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              {BRAND_VALUES.map((val, idx) => (
                <div key={idx} className="p-4 bg-zinc-900/60 rounded-xl border border-white/5 flex flex-col justify-between">
                  <div className="mb-2">
                    <span className="text-xs font-mono text-zinc-500 block mb-1">0{idx + 1}.</span>
                    <h4 className="text-xs font-bold uppercase text-white tracking-wide">{val.title}</h4>
                  </div>
                  <p className="text-[12px] text-zinc-400 leading-relaxed">{val.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right Column: Right-to-Left Brand Identity Card */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 flex flex-col items-center"
          >
            <div className="w-full bg-zinc-950 rounded-2xl border border-white/15 p-6 sm:p-8 flex flex-col items-center text-center shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-white/30 to-transparent" />

              {/* Logo Emblem badge */}
              <div className="mb-6">
                <BrandLogo variant="hero" />
              </div>

              {/* Website Name highlighted in bold letters */}
              <h3 className="text-2xl font-black text-white uppercase font-heading tracking-tight mb-1">
                JOHAR WALA OUTFIT
              </h3>
              <p className="text-xs font-serif italic text-zinc-400 mb-6">
                Outfit by hiituuu · Atelier est. Bharuch
              </p>

              {/* Verified Store Specs */}
              <div className="w-full bg-zinc-900/80 rounded-xl p-4 border border-white/10 text-left space-y-3 mb-6 text-xs">
                <div className="flex items-start gap-2.5">
                  <MapPin className="w-4 h-4 text-zinc-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-white block">Official Physical Store:</span>
                    <span className="text-zinc-400">{STORE_INFO.address}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 pt-2 border-t border-white/5">
                  <Phone className="w-4 h-4 text-zinc-400 shrink-0" />
                  <div>
                    <span className="font-semibold text-white block">Call & Order Inquiry:</span>
                    <a href={`tel:${STORE_INFO.phone}`} className="text-zinc-300 hover:text-white underline">
                      {STORE_INFO.displayPhone}
                    </a>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 pt-2 border-t border-white/5">
                  <Instagram className="w-4 h-4 text-pink-400 shrink-0" />
                  <div className="truncate">
                    <span className="font-semibold text-white block">Official Instagram:</span>
                    <a
                      href={STORE_INFO.instagramUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-zinc-300 hover:text-white underline truncate block"
                    >
                      {STORE_INFO.instagramHandle}
                    </a>
                  </div>
                </div>
              </div>

              {/* Instagram CTA */}
              <a
                href={STORE_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-3 px-4 text-xs font-bold text-white bg-zinc-900 hover:bg-zinc-800 border border-white/20 rounded-lg transition-all"
              >
                <Instagram className="w-4 h-4 text-pink-400" />
                <span>Follow on Instagram (@johar_walaoutfit)</span>
              </a>
            </div>
          </motion.div>
        </div>

        {/* Swipe Up: In-Store Atelier Experience Features */}
        <motion.div
          id="atelier"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="pt-10 border-t border-white/10"
        >
          <div className="text-center mb-8">
            <h3 className="text-xl sm:text-2xl font-bold uppercase text-white font-heading">
              THE IN-STORE EXPERIENCE AT AL NOOR CENTRE
            </h3>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1">
              What awaits you when you visit Shop #8 in Nandelav, Bharuch
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-zinc-950/60 rounded-xl border border-white/10 flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-xl bg-zinc-900 border border-white/15 flex items-center justify-center mb-4">
                <Scissors className="w-6 h-6 text-zinc-300" />
              </div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-2">
                Custom Hemming & Sizing
              </h4>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Whether you need cargo pant cuffs adjusted for your sneaker height or sleeves fitted, hiituuu provides complimentary fit adjustments in-store.
              </p>
            </div>

            <div className="p-6 bg-zinc-950/60 rounded-xl border border-white/10 flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-xl bg-zinc-900 border border-white/15 flex items-center justify-center mb-4">
                <Layers className="w-6 h-6 text-zinc-300" />
              </div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-2">
                Tactile Fabric Evaluation
              </h4>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Feel the density of our 280 to 420 GSM French terry fabrics and handspun linen weaves under proper studio lighting before deciding.
              </p>
            </div>

            <div className="p-6 bg-zinc-950/60 rounded-xl border border-white/10 flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-xl bg-zinc-900 border border-white/15 flex items-center justify-center mb-4">
                <Sparkles className="w-6 h-6 text-zinc-300" />
              </div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-2">
                Style Consultation by hiituuu
              </h4>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Get one-on-one silhouette guidance, layering combinations, and bespoke outfit pairing tailored for evening events, casual street outings, and festivals.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
